package com.besome.sketch.editor;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.os.Vibrator;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Pair;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.besome.sketch.beans.BlockBean;
import com.besome.sketch.beans.BlockCollectionBean;
import com.besome.sketch.beans.ComponentBean;
import com.besome.sketch.beans.HistoryBlockBean;
import com.besome.sketch.beans.MoreBlockCollectionBean;
import com.besome.sketch.beans.ProjectFileBean;
import com.besome.sketch.beans.ViewBean;
import com.besome.sketch.design.DesignActivity;
import com.besome.sketch.editor.component.AddComponentBottomSheet;
import com.besome.sketch.editor.logic.BlockPane;
import com.besome.sketch.editor.logic.LogicTopMenu;
import com.besome.sketch.editor.logic.PaletteBlock;
import com.besome.sketch.editor.logic.PaletteSelector;
import com.besome.sketch.editor.makeblock.MakeBlockActivity;
import com.besome.sketch.editor.manage.ShowBlockCollectionActivity;
import com.besome.sketch.editor.view.ViewDummy;
import com.besome.sketch.editor.view.ViewLogicEditor;
import com.besome.sketch.lib.base.BaseAppCompatActivity;
import com.besome.sketch.lib.ui.ColorPickerDialog;
import com.bumptech.glide.Glide;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

import a.a.a.DB;
import a.a.a.FB;
import a.a.a.Fx;
import a.a.a.GB;
import a.a.a.MA;
import a.a.a.Mp;
import a.a.a.NB;
import a.a.a.Ox;
import a.a.a.Pp;
import a.a.a.Rs;
import a.a.a.Ss;
import a.a.a.Ts;
import a.a.a.Us;
import a.a.a.Vs;
import a.a.a.ZB;
import a.a.a.bC;
import a.a.a.eC;
import a.a.a.jC;
import a.a.a.jq;
import a.a.a.kC;
import a.a.a.mB;
import a.a.a.sq;
import a.a.a.uq;
import a.a.a.wB;
import a.a.a.xB;
import a.a.a.yq;
import dev.aldi.sayuti.block.ExtraPaletteBlock;
import mod.bobur.VectorDrawableLoader;
import mod.hey.studios.editor.view.IdGenerator;
import mod.hey.studios.moreblock.ReturnMoreblockManager;
import mod.hey.studios.moreblock.importer.MoreblockImporterDialog;
import mod.hey.studios.project.ProjectSettings;
import mod.hey.studios.util.Helper;
import mod.hilal.saif.asd.AsdDialog;
import mod.jbk.editor.manage.MoreblockImporter;
import mod.jbk.util.BlockUtil;
import mod.jbk.util.LogUtil;
import mod.pranav.viewbinding.ViewBindingBuilder;
import pro.sketchware.R;
import pro.sketchware.activities.editor.view.CodeViewerActivity;
import pro.sketchware.activities.resourceseditor.ResourcesEditorActivity;
import pro.sketchware.databinding.ImagePickerItemBinding;
import pro.sketchware.databinding.SearchWithRecyclerViewBinding;
import pro.sketchware.menu.ExtraMenuBean;
import pro.sketchware.utility.FilePathUtil;
import pro.sketchware.utility.SketchwareUtil;
import pro.sketchware.utility.SvgUtils;
import pro.sketchware.utility.TranslationFunction;
import pro.sketchware.logic.LogicSyntaxChecker;
// AI / Clipboard / dialogs
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;

// AI project classes
import pro.sketchware.network.AiProviderService;
import pro.sketchware.network.AiRequestHandle;
import pro.sketchware.ia.LogicGenTask;
import android.widget.ProgressBar;
//classes BlocksConverter
import mod.sketchlibx.project.editor.BlocksConverter;


@SuppressLint({"ClickableViewAccessibility", "RtlHardcoded", "SetTextI18n", "DefaultLocale"})
public class LogicEditorActivity extends BaseAppCompatActivity implements View.OnClickListener, Vs, View.OnTouchListener, MoreblockImporterDialog.CallBack {
	
	private final Handler handler = new Handler();
	private final int[] v = new int[2];
	private final FirebaseCrashlytics crashlytics = FirebaseCrashlytics.getInstance();
	private final FilePathUtil fpu = new FilePathUtil();
	public ProjectFileBean M;
	public PaletteBlock m;
	public BlockPane o;
	public String scId = "";
	public String id = "";
	public String eventName = "";
	private Vibrator vibrator;
	private LinearLayout J, K;
	private FloatingActionButton openBlocksMenuButton;
	private LogicTopMenu logicTopMenu;
	private LogicEditorDrawer O;
	private ObjectAnimator U, V, ba, ca, fa, ga;
	private ExtraPaletteBlock extraPaletteBlock;
	private ViewLogicEditor viewLogicEditor;
	private ViewDummy dummy;
	private PaletteSelector paletteSelector;
	private final ActivityResultLauncher<Intent> openResourcesEditor = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
		if (result.getResultCode() == RESULT_OK) {
			paletteSelector.performClickPalette(-1);
		}
	});
	private Rs w;
	private float posInitY, posInitX, s, t;
	private int minDist, S, x, y;
	private int T = -30;
	private View currentTouchedView;
	private boolean G, isDragged, W, X, da, ea, ha, ia;
	private ArrayList<BlockBean> savedBlockBean = new ArrayList<>();
	private final Runnable longPressed = this::r;
	private Boolean isViewBindingEnabled;
	
	// Syntax check fields
	private LinearLayout syntaxCheckContainer;
	private ImageView syntaxCheckIcon;
	private TextView syntaxCheckText;
	private final Handler syntaxCheckHandler = new Handler();
	private final Runnable syntaxCheckRunnable = this::runSyntaxCheck;
	private SvgUtils svgUtils;
	
	// تعديل runSyntaxCheck لاستخدام خيط معالجة آمن وتفادي إنشائه باستمرار
	private final ExecutorService syntaxExecutor = Executors.newSingleThreadExecutor();
	// يحتفظ بمقبض الطلب الجاري حتى نتمكن من إلغائه
	private volatile AiRequestHandle activeAiRequest;
	
	
	public static ArrayList<String> getAllJavaFileNames(String projectScId) {
		ArrayList<String> javaFileNames = new ArrayList<>();
		for (ProjectFileBean projectFile : jC.b(projectScId).b()) {
			javaFileNames.add(projectFile.getJavaName());
		}
		return javaFileNames;
	}
	
	public static ArrayList<String> getAllXmlFileNames(String projectScId) {
		ArrayList<String> xmlFileNames = new ArrayList<>();
		for (ProjectFileBean projectFile : jC.b(projectScId).b()) {
			String xmlName = projectFile.getXmlName();
			if (xmlName != null && !xmlName.isEmpty()) {
				xmlFileNames.add(xmlName);
			}
		}
		return xmlFileNames;
	}
	
	private void loadEventBlocks() {
		crashlytics.log("Loading event blocks");
		ArrayList<BlockBean> eventBlocks = jC.a(scId).a(M.getJavaName(), id + "_" + eventName);
		if (eventBlocks != null) {
			if (eventBlocks.isEmpty()) {
				runOnUiThread(() -> e(X));
			}
			
			boolean needToFindRoot = true;
			HashMap<Integer, Rs> blockIdsAndBlocks = new HashMap<>();
			for (BlockBean next : eventBlocks) {
				if (eventName.equals("onTextChanged") && next.opCode.equals("getArg") && next.spec.equals("text")) {
					next.spec = "charSeq";
				}
				Rs b2 = b(next);
				blockIdsAndBlocks.put((Integer) b2.getTag(), b2);
				o.g = Math.max(o.g, (Integer) b2.getTag() + 1);
				runOnUiThread(() -> {
					o.a(b2, 0, 0);
					b2.setOnTouchListener(this);
				});
				if (needToFindRoot) {
					runOnUiThread(() -> o.getRoot().b(b2));
					needToFindRoot = false;
				}
			}
			for (BlockBean next2 : eventBlocks) {
				Rs block = blockIdsAndBlocks.get(Integer.valueOf(next2.id));
				if (block != null) {
					Rs subStack1RootBlock;
					if (next2.subStack1 >= 0 && (subStack1RootBlock = blockIdsAndBlocks.get(next2.subStack1)) != null) {
						runOnUiThread(() -> block.e(subStack1RootBlock));
					}
					Rs subStack2RootBlock;
					if (next2.subStack2 >= 0 && (subStack2RootBlock = blockIdsAndBlocks.get(next2.subStack2)) != null) {
						runOnUiThread(() -> block.f(subStack2RootBlock));
					}
					Rs nextBlock;
					if (next2.nextBlock >= 0 && (nextBlock = blockIdsAndBlocks.get(next2.nextBlock)) != null) {
						runOnUiThread(() -> block.b(nextBlock));
					}
					for (int i = 0; i < next2.parameters.size(); i++) {
						String parameter = next2.parameters.get(i);
						if (parameter != null && !parameter.isEmpty()) {
							if (parameter.charAt(0) == '@') {
								Rs parameterBlock = blockIdsAndBlocks.get(Integer.valueOf(parameter.substring(1)));
								if (parameterBlock != null) {
									int finalI = i;
									runOnUiThread(() -> block.a((Ts) block.V.get(finalI), parameterBlock));
								}
							} else {
								int finalI = i;
								runOnUiThread(() -> {
									((Ss) block.V.get(finalI)).setArgValue(parameter);
									block.m();
								});
							}
						}
					}
				}
			}
			runOnUiThread(() -> {
				o.getRoot().k();
				o.b();
				triggerSyntaxCheck();
			});
		}
	}
	
	private void redo() {
		if (!isDragged) {
			HistoryBlockBean historyBlockBean = bC.d(scId).i(s());
			if (historyBlockBean != null) {
				int actionType = historyBlockBean.getActionType();
				if (actionType == HistoryBlockBean.ACTION_TYPE_ADD) {
					int[] locationOnScreen = new int[2];
					o.getLocationOnScreen(locationOnScreen);
					a(historyBlockBean.getAddedData(), historyBlockBean.getCurrentX() + locationOnScreen[0], historyBlockBean.getCurrentY() + locationOnScreen[1], true);
					if (historyBlockBean.getCurrentParentData() != null) {
						a(historyBlockBean.getCurrentParentData(), true);
					}
				} else if (actionType == HistoryBlockBean.ACTION_TYPE_UPDATE) {
					a(historyBlockBean.getCurrentUpdateData(), true);
				} else if (actionType == HistoryBlockBean.ACTION_TYPE_REMOVE) {
					ArrayList<BlockBean> removedData = historyBlockBean.getRemovedData();
					
					for (int i = removedData.size() - 1; i >= 0; i--) {
						o.a(removedData.get(i), false);
					}
					if (historyBlockBean.getCurrentParentData() != null) {
						a(historyBlockBean.getCurrentParentData(), true);
					}
				} else if (actionType == HistoryBlockBean.ACTION_TYPE_MOVE) {
					for (BlockBean afterMoveData : historyBlockBean.getAfterMoveData()) {
						o.a(afterMoveData, true);
					}
					
					int[] locationOnScreen = new int[2];
					o.getLocationOnScreen(locationOnScreen);
					a(historyBlockBean.getAfterMoveData(), historyBlockBean.getCurrentX() + locationOnScreen[0], historyBlockBean.getCurrentY() + locationOnScreen[1], true);
					if (historyBlockBean.getCurrentParentData() != null) {
						a(historyBlockBean.getCurrentParentData(), true);
					}
					
					if (historyBlockBean.getCurrentOriginalParent() != null) {
						a(historyBlockBean.getCurrentOriginalParent(), true);
					}
				}
			}
			invalidateOptionsMenu();
		}
	}
	
	public void C() {
		invalidateOptionsMenu();
		triggerSyntaxCheck();
	}
	
	public void E() {
		eC a2 = jC.a(scId);
		String javaName = M.getJavaName();
		a2.a(javaName, id + "_" + eventName, o.getBlocks());
	}
	
	public void G() {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_editor_title_add_new_list);
		View a2 = wB.a(this, R.layout.logic_popup_add_list);
		RadioGroup radioGroup = a2.findViewById(R.id.rg_type);
		TextInputEditText editText = a2.findViewById(R.id.ed_input);
		ZB zb = new ZB(getContext(), a2.findViewById(R.id.ti_input), uq.b, uq.a(), jC.a(scId).a(M));
		dialog.setView(a2);
		dialog.setPositiveButton(R.string.common_word_add, (v, which) -> {
			if (zb.b()) {
				int i = 1;
				int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();
				if (checkedRadioButtonId != R.id.rb_int) {
					if (checkedRadioButtonId == R.id.rb_string) {
						i = 2;
					} else if (checkedRadioButtonId == R.id.rb_map) {
						i = 3;
					}
				}
				
				a(i, Helper.getText(editText));
				v.dismiss();
			}
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	private void showAddNewVariableDialog() {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_editor_title_add_new_variable);
		
		View customView = wB.a(this, R.layout.logic_popup_add_variable);
		RadioGroup radioGroup = customView.findViewById(R.id.rg_type);
		TextInputEditText editText = customView.findViewById(R.id.ed_input);
		ZB nameValidator = new ZB(getContext(), customView.findViewById(R.id.ti_input), uq.b, uq.a(), jC.a(scId).a(M));
		dialog.setView(customView);
		dialog.setPositiveButton(R.string.common_word_add, (v, which) -> {
			int variableType = 1;
			if (radioGroup.getCheckedRadioButtonId() == R.id.rb_boolean) {
				variableType = 0;
			} else if (radioGroup.getCheckedRadioButtonId() != R.id.rb_int) {
				if (radioGroup.getCheckedRadioButtonId() == R.id.rb_string) {
					variableType = 2;
				} else if (radioGroup.getCheckedRadioButtonId() == R.id.rb_map) {
					variableType = 3;
				}
			}
			
			if (nameValidator.b()) {
				b(variableType, Helper.getText(editText));
				v.dismiss();
			}
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void openResourcesEditor() {
		Intent intent = new Intent();
		intent.setClass(getApplicationContext(), ResourcesEditorActivity.class);
		intent.putExtra("sc_id", scId);
		openResourcesEditor.launch(intent);
	}
	
	public void I() {
		ArrayList<MoreBlockCollectionBean> moreBlocks = Pp.h().f();
		new MoreblockImporterDialog(this, moreBlocks, this).show();
	}
	
	public void J() {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_editor_title_remove_list);
		View a2 = wB.a(this, R.layout.property_popup_selector_single);
		ViewGroup viewGroup = a2.findViewById(R.id.rg_content);
		for (Pair<Integer, String> list : jC.a(scId).j(M.getJavaName())) {
			viewGroup.addView(e(list.second));
		}
		dialog.setView(a2);
		dialog.setPositiveButton(R.string.common_word_remove, (v, which) -> {
			int childCount = viewGroup.getChildCount();
			int i = 0;
			while (i < childCount) {
				RadioButton radioButton = (RadioButton) viewGroup.getChildAt(i);
				if (radioButton.isChecked()) {
					if (!o.b(Helper.getText(radioButton))) {
						if (!jC.a(scId).b(M.getJavaName(), Helper.getText(radioButton), id + "_" + eventName)) {
							l(Helper.getText(radioButton));
						}
					}
					Toast.makeText(getContext(), R.string.logic_editor_message_currently_used_list, Toast.LENGTH_SHORT).show();
					return;
				}
				i++;
			}
			v.dismiss();
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void K() {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_editor_title_remove_variable);
		View a2 = wB.a(this, R.layout.property_popup_selector_single);
		ViewGroup viewGroup = a2.findViewById(R.id.rg_content);
		for (Pair<Integer, String> next : jC.a(scId).k(M.getJavaName())) {
			RadioButton e = e(next.second);
			e.setTag(next.first);
			viewGroup.addView(e);
		}
		dialog.setView(a2);
		dialog.setPositiveButton(R.string.common_word_remove, (v, which) -> {
			int childCount = viewGroup.getChildCount();
			int i = 0;
			while (i < childCount) {
				RadioButton radioButton = (RadioButton) viewGroup.getChildAt(i);
				if (radioButton.isChecked()) {
					if (!o.c(Helper.getText(radioButton))) {
						if (!jC.a(scId).c(M.getJavaName(), Helper.getText(radioButton), id + "_" + eventName)) {
							m(Helper.getText(radioButton));
						}
					}
					Toast.makeText(getContext(), R.string.logic_editor_message_currently_used_variable, Toast.LENGTH_SHORT).show();
					return;
				}
				i++;
			}
			v.dismiss();
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void L() {
		try {
			new Handler().postDelayed(() -> new ProjectSaver(this).execute(), 500L);
		} catch (Exception e) {
			crashlytics.recordException(e);
		}
	}
	
	private void undo() {
		if (!isDragged) {
			HistoryBlockBean history = bC.d(scId).j(s());
			if (history != null) {
				int actionType = history.getActionType();
				if (actionType == HistoryBlockBean.ACTION_TYPE_ADD) {
					ArrayList<BlockBean> addedData = history.getAddedData();
					for (int i = addedData.size() - 1; i >= 0; i--) {
						o.a(addedData.get(i), false);
					}
					
					if (history.getPrevParentData() != null) {
						history.getPrevParentData().print();
						a(history.getPrevParentData(), true);
					}
				} else if (actionType == HistoryBlockBean.ACTION_TYPE_UPDATE) {
					a(history.getPrevUpdateData(), true);
				} else if (actionType == HistoryBlockBean.ACTION_TYPE_REMOVE) {
					int[] oLocationOnScreen = new int[2];
					o.getLocationOnScreen(oLocationOnScreen);
					a(history.getRemovedData(), history.getCurrentX() + oLocationOnScreen[0], history.getCurrentY() + oLocationOnScreen[1], true);
					
					if (history.getPrevParentData() != null) {
						a(history.getPrevParentData(), true);
					}
				} else if (actionType == HistoryBlockBean.ACTION_TYPE_MOVE) {
					for (BlockBean beforeMoveBlock : history.getBeforeMoveData()) {
						o.a(beforeMoveBlock, true);
					}
					
					int[] oLocationOnScreen = new int[2];
					o.getLocationOnScreen(oLocationOnScreen);
					a(history.getBeforeMoveData(), history.getPrevX() + oLocationOnScreen[0], history.getPrevY() + oLocationOnScreen[1], true);
					
					if (history.getPrevParentData() != null) {
						a(history.getPrevParentData(), true);
					}
					if (history.getPrevOriginalParent() != null) {
						a(history.getPrevOriginalParent(), true);
					}
				}
			}
			
			invalidateOptionsMenu();
		}
	}
	
	public Rs a(Rs rs, int i, int i2, boolean z) {
		Rs a2 = o.a(rs, i, i2, z);
		if (!z) {
			a2.setOnTouchListener(this);
		}
		return a2;
	}
	
	public void addDeprecatedBlock(String message, String type, String opCode) {
		m.addDeprecatedBlock(message, type, opCode);
	}
	
	public View a(String str, String str2) {
		Ts a2 = m.a("", str, str2);
		a2.setTag(str2);
		a2.setClickable(true);
		a2.setOnTouchListener(this);
		return a2;
	}
	
	public final View a(String str, String str2, String str3) {
		Ts a2 = m.a(str, str2, str3);
		a2.setTag(str3);
		a2.setClickable(true);
		a2.setOnTouchListener(this);
		return a2;
	}
	
	public final View a(String str, String str2, String str3, String str4) {
		Ts a2 = m.a(str, str2, str3, str4);
		a2.setTag(str4);
		a2.setClickable(true);
		a2.setOnTouchListener(this);
		return a2;
	}
	
	private ImageView setImageViewContent(String name) {
		float dp = wB.a(this, 1.0f);
		int size = (int) (dp * 48);
		ImageView imageView = new ImageView(this);
		imageView.setLayoutParams(new LinearLayout.LayoutParams(size, size));
		imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
		imageView.setBackgroundResource(R.drawable.bg_outline);
		
		if ("NONE".equals(name)) {
			return imageView;
		}
		
		if ("default_image".equals(name)) {
			int resId = getResources().getIdentifier(name, "drawable", getPackageName());
			if (resId != 0) imageView.setImageResource(resId);
			return imageView;
		}
		
		File imageFile = new File(jC.d(scId).f(name));
		if (imageFile.exists()) {
			String path = imageFile.getAbsolutePath();
			Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", imageFile);
			
			if (path.endsWith(".xml")) {
				svgUtils.loadImage(imageView, fpu.getSvgFullPath(scId, name));
			} else {
				Glide.with(this)
				.load(uri)
				.signature(kC.n())
				.error(R.drawable.ic_remove_grey600_24dp)
				.into(imageView);
			}
		} else {
			try {
				new VectorDrawableLoader().setImageVectorFromFile(imageView, new VectorDrawableLoader().getVectorFullPath(DesignActivity.sc_id, name));
			} catch (Exception e) {
				imageView.setImageResource(R.drawable.ic_remove_grey600_24dp);
			}
		}
		
		return imageView;
	}
	
	public final ArrayList<BlockBean> a(ArrayList<BlockBean> arrayList, int i, int i2, boolean z) {
		HashMap<Integer, Integer> hashMap = new HashMap<>();
		ArrayList<BlockBean> arrayList2 = new ArrayList<>();
		for (BlockBean next : arrayList) {
			if (next.id != null && !next.id.isEmpty()) {
				arrayList2.add(next.clone());
			}
		}
		for (BlockBean next2 : arrayList2) {
			if (Integer.parseInt(next2.id) >= 99000000) {
				hashMap.put(Integer.valueOf(next2.id), o.g);
				o.g = o.g + 1;
			} else {
				hashMap.put(Integer.valueOf(next2.id), Integer.valueOf(next2.id));
			}
		}
		int size = arrayList2.size();
		while (true) {
			size--;
			if (size < 0) {
				break;
			}
			BlockBean blockBean = arrayList2.get(size);
			if (!a(blockBean)) {
				arrayList2.remove(size);
				hashMap.remove(Integer.valueOf(blockBean.id));
			}
		}
		for (BlockBean block : arrayList2) {
			if (hashMap.containsKey(Integer.valueOf(block.id))) {
				block.id = String.valueOf(hashMap.get(Integer.valueOf(block.id)));
			} else {
				block.id = "";
			}
			for (int j = 0; j < block.parameters.size(); j++) {
				String parameter = block.parameters.get(j);
				if (parameter != null && !parameter.isEmpty() && parameter.charAt(0) == '@') {
					int parameterId = Integer.parseInt(parameter.substring(1));
					int parameterAsBlockId = hashMap.containsKey(parameterId) ? hashMap.get(parameterId) : 0;
					if (parameterAsBlockId >= 0) {
						block.parameters.set(j, '@' + String.valueOf(parameterAsBlockId));
					} else {
						block.parameters.set(j, "");
					}
				}
			}
			if (block.subStack1 >= 0 && hashMap.containsKey(block.subStack1)) {
				block.subStack1 = hashMap.get(block.subStack1);
			}
			if (block.subStack2 >= 0 && hashMap.containsKey(block.subStack2)) {
				block.subStack2 = hashMap.get(block.subStack2);
			}
			if (block.nextBlock >= 0 && hashMap.containsKey(block.nextBlock)) {
				block.nextBlock = hashMap.get(block.nextBlock);
			}
		}
		Rs firstBlock = null;
		for (int j = 0; j < arrayList2.size(); j++) {
			BlockBean blockBean = arrayList2.get(j);
			if (blockBean.id != null && !blockBean.id.isEmpty()) {
				Rs block = b(blockBean);
				if (j == 0) {
					firstBlock = block;
				}
				o.a(block, i, i2);
				block.setOnTouchListener(this);
			}
		}
		for (BlockBean block : arrayList2) {
			if (block.id != null && !block.id.isEmpty()) {
				a(block, false);
			}
		}
		if (firstBlock != null && z) {
			firstBlock.p().k();
			o.b();
		}
		return arrayList2;
	}
	
	@Override
	public void a(int i, int i2) {
		extraPaletteBlock.setBlock(i, i2);
	}
	
	public void a(int i, String str) {
		jC.a(scId).b(M.getJavaName(), i, str);
		a(1, 0xffcc5b22);
	}
	
	public void a(Rs rs) {
		w = null;
		y = -1;
		x = 0;
		int[] iArr = new int[2];
		Rs rs2 = rs.E;
		if (rs2 != null) {
			w = rs2;
			if (savedBlockBean.isEmpty()) {
				savedBlockBean = o.getBlocks();
			}
		}
		Rs rs3 = w;
		if (rs3 == null) {
			return;
		}
		if (rs3.ha == (Integer) rs.getTag()) {
			x = 0;
		} else if (w.ia == (Integer) rs.getTag()) {
			x = 2;
		} else if (w.ja == (Integer) rs.getTag()) {
			x = 3;
		} else if (w.V.contains(rs)) {
			x = 5;
			y = w.V.indexOf(rs);
		}
	}
	
	public void a(Rs rs, float f, float f2) {
		for (View next : rs.V) {
			if ((next instanceof Ss) && next.getX() < f && next.getX() + next.getWidth() > f && next.getY() < f2 && next.getY() + next.getHeight() > f2) {
				new ExtraMenuBean(this).defineMenuSelector((Ss) next);
				return;
			}
		}
	}
	
	public void a(Ss ss, Object obj) {
		BlockBean clone = ss.E.getBean().clone();
		ss.setArgValue(obj);
		ss.E.m();
		ss.E.p().k();
		ss.E.pa.b();
		bC.d(scId).a(s(), clone, ss.E.getBean().clone());
		C();
	}
	
	public void pickImage(Ss ss, String str) {
		boolean selectingBackgroundImage = "property_background_resource".equals(str);
		boolean selectingImage = !selectingBackgroundImage && "property_image".equals(str);
		AtomicReference<String> selectedImage = new AtomicReference<>("");
		
		SearchWithRecyclerViewBinding binding = SearchWithRecyclerViewBinding.inflate(getLayoutInflater());
		
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		if (selectingImage) {
			dialog.setTitle(R.string.logic_editor_title_select_image);
		} else if (selectingBackgroundImage) {
			dialog.setTitle(R.string.logic_editor_title_select_image_background);
		}
		
		binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
		
		ArrayList<String> images = jC.d(scId).m();
		images.addAll(new VectorDrawableLoader().getVectorDrawables(DesignActivity.sc_id));
		if (selectingImage) {
			images.add(0, "default_image");
		} else if (selectingBackgroundImage) {
			images.add(0, "NONE");
		}
		
		ImagePickerAdapter adapter = new ImagePickerAdapter(images, (String) ss.getArgValue(), selectedImage::set);
		binding.recyclerView.setAdapter(adapter);
		
		
		binding.searchInput.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				String query = s.toString().toLowerCase();
				adapter.filter(query);
			}
		});
		
		dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
			String selectedImg = selectedImage.get();
			if (!selectedImg.isEmpty()) {
				a(ss, selectedImage.get());
			}
		});
		
		dialog.setView(binding.getRoot());
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void a(Ss ss, boolean z) {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(z ? R.string.logic_editor_title_enter_number_value : R.string.logic_editor_title_enter_string_value);
		View a2 = wB.a(this, R.layout.property_popup_input_text);
		EditText editText = a2.findViewById(R.id.ed_input);
		if (z) {
			editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
			editText.setImeOptions(EditorInfo.IME_ACTION_DONE);
			editText.setMaxLines(1);
		} else {
			editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
			editText.setImeOptions(EditorInfo.IME_ACTION_NONE);
		}
		editText.setText(ss.getArgValue().toString());
		dialog.setView(a2);
		dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
			String text = Helper.getText(editText);
			emptyStringSetter:
			{
				if (z) {
					try {
						double d = Double.parseDouble(text);
						if (!Double.isNaN(d) && !Double.isInfinite(d)) {
							break emptyStringSetter;
						}
					} catch (NumberFormatException e) {
						LogUtil.e("LogicEditor", "", e);
					}
				} else if (!text.isEmpty()) {
					if (text.charAt(0) == '@') {
						text = " " + text;
						break emptyStringSetter;
					}
				}
				
				text = "";
			}
			
			a(ss, text);
			v.dismiss();
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void a(BlockBean blockBean, boolean z) {
		Rs block = o.a(blockBean.id);
		if (block != null) {
			block.ia = -1;
			block.ja = -1;
			block.ha = -1;
			
			for (int i = 0; i < blockBean.parameters.size(); i++) {
				String parameter = blockBean.parameters.get(i);
				if (parameter != null) {
					if (!parameter.isEmpty() && parameter.charAt(0) == '@') {
						int blockId = Integer.parseInt(parameter.substring(1));
						if (blockId > 0) {
							Rs parameterBlock = o.a(blockId);
							if (parameterBlock != null) {
								block.a((Ts) block.V.get(i), parameterBlock);
							}
						}
					} else {
						if (block.V.get(i) instanceof Ss ss) {
							String javaName = M.getJavaName();
							String xmlName = M.getXmlName();
							if (eventName.equals("onBindCustomView")) {
								var eC = jC.a(scId);
								var view = eC.c(xmlName, id);
								if (view == null) {
									// Event is of a Drawer View
									view = eC.c("_drawer_" + xmlName, id);
								}
								String customView = view.customView;
								if (customView != null) {
									xmlName = ProjectFileBean.getXmlName(customView);
								}
							}
							
							if (!parameter.isEmpty()) {
								if (ss.b.equals("m")) {
									eC eC = jC.a(scId);
									
									switch (ss.c) {
										case "varInt":
										eC.f(javaName, ExtraMenuBean.VARIABLE_TYPE_NUMBER, parameter);
										break;
										
										case "varBool":
										eC.f(javaName, ExtraMenuBean.VARIABLE_TYPE_BOOLEAN, parameter);
										break;
										
										case "varStr":
										eC.f(javaName, ExtraMenuBean.VARIABLE_TYPE_STRING, parameter);
										break;
										
										case "listInt":
										eC.e(javaName, ExtraMenuBean.LIST_TYPE_NUMBER, parameter);
										break;
										
										case "listStr":
										eC.e(javaName, ExtraMenuBean.LIST_TYPE_STRING, parameter);
										break;
										
										case "listMap":
										eC.e(javaName, ExtraMenuBean.LIST_TYPE_MAP, parameter);
										break;
										
										case "list":
										boolean b = eC.e(javaName, ExtraMenuBean.LIST_TYPE_NUMBER, parameter);
										if (!b) {
											b = eC.e(javaName, ExtraMenuBean.LIST_TYPE_STRING, parameter);
										}
										
										if (!b) {
											eC.e(javaName, ExtraMenuBean.LIST_TYPE_MAP, parameter);
										}
										break;
										
										case "view":
										eC.h(xmlName, parameter);
										break;
										
										case "textview":
										eC.g(xmlName, parameter);
										break;
										
										case "checkbox":
										eC.e(xmlName, parameter);
										break;
										
										case "imageview":
										eC.g(xmlName, ViewBean.VIEW_TYPE_WIDGET_IMAGEVIEW, parameter);
										break;
										
										case "seekbar":
										eC.g(xmlName, ViewBean.VIEW_TYPE_WIDGET_SEEKBAR, parameter);
										break;
										
										case "calendarview":
										eC.g(xmlName, ViewBean.VIEW_TYPE_WIDGET_CALENDARVIEW, parameter);
										break;
										
										case "adview":
										eC.g(xmlName, ViewBean.VIEW_TYPE_WIDGET_ADVIEW, parameter);
										break;
										
										case "listview":
										eC.g(xmlName, ViewBean.VIEW_TYPE_WIDGET_LISTVIEW, parameter);
										break;
										
										case "spinner":
										eC.g(xmlName, ViewBean.VIEW_TYPE_WIDGET_SPINNER, parameter);
										break;
										
										case "webview":
										eC.g(xmlName, ViewBean.VIEW_TYPE_WIDGET_WEBVIEW, parameter);
										break;
										
										case "switch":
										eC.g(xmlName, ViewBean.VIEW_TYPE_WIDGET_SWITCH, parameter);
										break;
										
										case "progressbar":
										eC.g(xmlName, ViewBean.VIEW_TYPE_WIDGET_PROGRESSBAR, parameter);
										break;
										
										case "mapview":
										eC.g(xmlName, ViewBean.VIEW_TYPE_WIDGET_MAPVIEW, parameter);
										break;
										
										case "intent":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_INTENT, parameter);
										break;
										
										case "file":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_SHAREDPREF, parameter);
										break;
										
										case "calendar":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_CALENDAR, parameter);
										break;
										
										case "timer":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_TIMERTASK, parameter);
										break;
										
										case "vibrator":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_VIBRATOR, parameter);
										break;
										
										case "dialog":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_DIALOG, parameter);
										break;
										
										case "mediaplayer":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_MEDIAPLAYER, parameter);
										break;
										
										case "soundpool":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_SOUNDPOOL, parameter);
										break;
										
										case "objectanimator":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_OBJECTANIMATOR, parameter);
										break;
										
										case "firebase":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_FIREBASE, parameter);
										break;
										
										case "firebaseauth":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_FIREBASE_AUTH, parameter);
										break;
										
										case "firebasestorage":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_FIREBASE_STORAGE, parameter);
										break;
										
										case "gyroscope":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_GYROSCOPE, parameter);
										break;
										
										case "compass":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_COMPASS, parameter);
										break;
										
										case "lightsensor":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_LIGHT_SENSOR, parameter);
										break;
										
										case "proximitysensor":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_PROXIMITY_SENSOR, parameter);
										break;
										
										case "barometer":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_BAROMETER, parameter);
										break;
										
										case "stepcounter":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_STEP_COUNTER, parameter);
										break;
										
										case "workmanager":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_WORK_MANAGER, parameter);
										break;
										
										case "alarmmanager":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_ALARM_MANAGER, parameter);
										break;
										
										case "biometricmanager":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_BIOMETRIC_MANAGER, parameter);
										break;
										
										case "fusedlocationmanager":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_FUSED_LOCATION_MANAGER, parameter);
										break;
										
										case "interstitialad":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_INTERSTITIAL_AD, parameter);
										break;
										
										case "requestnetwork":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_REQUEST_NETWORK, parameter);
										break;
										
										case "texttospeech":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_TEXT_TO_SPEECH, parameter);
										break;
										
										case "speechtotext":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_SPEECH_TO_TEXT, parameter);
										break;
										
										case "bluetoothconnect":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_BLUETOOTH_CONNECT, parameter);
										break;
										
										case "locationmanager":
										eC.d(javaName, ComponentBean.COMPONENT_TYPE_LOCATION_MANAGER, parameter);
										break;
										
										case "resource_bg":
										case "resource":
										for (String str : jC.d(scId).m()) {
											// Like this in vanilla Sketchware. Don't ask me why.
											//noinspection StatementWithEmptyBody
											if (parameter.equals(str)) {
											}
										}
										break;
										
										case "activity":
										for (String str : jC.b(scId).d()) {
											// Like this in vanilla Sketchware. Don't ask me why.
											//noinspection StatementWithEmptyBody
											if (parameter.equals(str.substring(str.indexOf(".java")))) {
											}
										}
										break;
										
										case "sound":
										for (String str : jC.d(scId).p()) {
											// Like this in vanilla Sketchware. Don't ask me why.
											//noinspection StatementWithEmptyBody
											if (parameter.equals(str)) {
											}
										}
										break;
										
										case "videoad":
										eC.d(xmlName, ComponentBean.COMPONENT_TYPE_REWARDED_VIDEO_AD, parameter);
										break;
										
										case "progressdialog":
										eC.d(xmlName, ComponentBean.COMPONENT_TYPE_PROGRESS_DIALOG, parameter);
										break;
										
										case "datepickerdialog":
										eC.d(xmlName, ComponentBean.COMPONENT_TYPE_DATE_PICKER_DIALOG, parameter);
										break;
										
										case "timepickerdialog":
										eC.d(xmlName, ComponentBean.COMPONENT_TYPE_TIME_PICKER_DIALOG, parameter);
										break;
										
										case "notification":
										eC.d(xmlName, ComponentBean.COMPONENT_TYPE_NOTIFICATION, parameter);
										break;
										
										case "radiobutton":
										eC.g(xmlName, 19, parameter);
										break;
										
										case "ratingbar":
										eC.g(xmlName, 20, parameter);
										break;
										
										case "videoview":
										eC.g(xmlName, 21, parameter);
										break;
										
										case "searchview":
										eC.g(xmlName, 22, parameter);
										break;
										
										case "actv":
										eC.g(xmlName, 23, parameter);
										break;
										
										case "mactv":
										eC.g(xmlName, 24, parameter);
										break;
										
										case "gridview":
										eC.g(xmlName, 25, parameter);
										break;
										
										case "tablayout":
										eC.g(xmlName, 30, parameter);
										break;
										
										case "viewpager":
										eC.g(xmlName, 31, parameter);
										break;
										
										case "bottomnavigation":
										eC.g(xmlName, 32, parameter);
										break;
										
										case "badgeview":
										eC.g(xmlName, 33, parameter);
										break;
										
										case "patternview":
										eC.g(xmlName, 34, parameter);
										break;
										
										case "sidebar":
										eC.g(xmlName, 35, parameter);
										break;
										
										default:
										extraPaletteBlock.e(ss.c, parameter);
									}
								}
							}
							
							ss.setArgValue(parameter);
							block.m();
						}
					}
				}
			}
			
			int subStack1RootBlockId = blockBean.subStack1;
			if (subStack1RootBlockId >= 0) {
				Rs subStack1RootBlock = o.a(subStack1RootBlockId);
				if (subStack1RootBlock != null) {
					block.e(subStack1RootBlock);
				}
			}
			
			int subStack2RootBlockId = blockBean.subStack2;
			if (subStack2RootBlockId >= 0) {
				Rs subStack2RootBlock = o.a(subStack2RootBlockId);
				if (subStack2RootBlock != null) {
					block.f(subStack2RootBlock);
				}
			}
			
			int nextBlockId = blockBean.nextBlock;
			if (nextBlockId >= 0) {
				Rs nextBlock = o.a(nextBlockId);
				if (nextBlock != null) {
					block.b(nextBlock);
				}
			}
			
			block.m();
			if (z) {
				block.p().k();
				o.b();
			}
		}
	}
	
	public void a(String str, int i) {
		m.a(str, i);
	}
	
	public void a(String str, Rs rs) {
		ArrayList<String> arrayList;
		ArrayList<Rs> allChildren = rs.getAllChildren();
		ArrayList<BlockBean> arrayList2 = new ArrayList<>();
		for (Rs child : allChildren) {
			BlockBean blockBean = new BlockBean();
			BlockBean bean = child.getBean();
			blockBean.copy(bean);
			blockBean.id = String.format("99%06d", Integer.valueOf(bean.id));
			int i = bean.subStack1;
			if (i > 0) {
				blockBean.subStack1 = i + 99000000;
			}
			int i2 = bean.subStack2;
			if (i2 > 0) {
				blockBean.subStack2 = i2 + 99000000;
			}
			int i3 = bean.nextBlock;
			if (i3 > 0) {
				blockBean.nextBlock = i3 + 99000000;
			}
			blockBean.parameters.clear();
			for (String next : bean.parameters) {
				if (next.length() <= 1 || next.charAt(0) != '@') {
					arrayList = blockBean.parameters;
				} else {
					String format = String.format("99%06d", Integer.valueOf(next.substring(1)));
					arrayList = blockBean.parameters;
					next = '@' + format;
				}
				arrayList.add(next);
			}
			arrayList2.add(blockBean);
		}
		try {
			Mp.h().a(str, arrayList2, true);
			O.a(str, arrayList2).setOnTouchListener(this);
		} catch (Exception e) {
			crashlytics.recordException(e);
		}
	}
	
	public void a(boolean z) {
		logicTopMenu.setCopyActive(z);
	}
	
	public final boolean a(float f, float f2) {
		return logicTopMenu.isInsideCopyArea(f, f2);
	}
	
	public final boolean a(BlockBean blockBean) {
		if (blockBean.opCode.equals("getArg")) {
			return true;
		}
		if (blockBean.opCode.equals("definedFunc")) {
			Iterator<Pair<String, String>> it = jC.a(scId).i(M.getJavaName()).iterator();
			boolean z = false;
			while (it.hasNext()) {
				if (blockBean.spec.equals(ReturnMoreblockManager.getMbName(it.next().second))) {
					z = true;
				}
			}
			return z;
		}
		return true;
	}
	
	public Rs b(BlockBean blockBean) {
		return new Rs(this, Integer.parseInt(blockBean.id), blockBean.spec, blockBean.type, blockBean.typeName, blockBean.opCode);
	}
	
	private RadioButton getFontRadioButton(String fontName) {
		RadioButton radioButton = new RadioButton(this);
		radioButton.setText("");
		radioButton.setTag(fontName);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (wB.a(this, 1.0f) * 60.0f));
		radioButton.setGravity(Gravity.CENTER | Gravity.LEFT);
		radioButton.setLayoutParams(layoutParams);
		return radioButton;
	}
	
	public void b(int i, String str) {
		jC.a(scId).c(M.getJavaName(), i, str);
		a(0, 0xffee7d16);
	}
	
	public void b(Rs rs) {
		o.b(rs);
	}
	
	public void b(Ss ss) {
		ColorPickerDialog colorPickerDialog = new ColorPickerDialog(this, (ss.getArgValue() == null || ss.getArgValue().toString().isEmpty()) ? "Color.TRANSPARENT" : ss.getArgValue().toString().replace("0xFF", "#"), true, false, scId);
		colorPickerDialog.a(new ColorPickerDialog.b() {
			@Override
			public void a(int var1) {
				if (var1 == 0) {
					LogicEditorActivity.this.a(ss, "Color.TRANSPARENT");
				} else {
					LogicEditorActivity.this.a(ss, String.format("0x%08X", var1 & (Color.WHITE)));
				}
			}
			
			@Override
			public void a(String var1, int var2) {
				LogicEditorActivity.this.a(ss, "R.color." + var1);
			}
		});
		colorPickerDialog.materialColorAttr((attr, attrColor) -> a(ss, "R.attr." + attr));
		colorPickerDialog.showAtLocation(ss, Gravity.CENTER, 0, 0);
	}
	
	public void b(String str, String tag) {
		TextView textView = m.a(str);
		textView.setTag(tag);
		textView.setSoundEffectsEnabled(true);
		textView.setOnClickListener(this);
	}
	
	public void b(String str, String tag, View.OnClickListener onClickListener) {
		TextView textView = m.a(str);
		textView.setTag(tag);
		textView.setSoundEffectsEnabled(true);
		textView.setOnClickListener(onClickListener);
	}
	
	public void activeIconDelete(boolean showDeleteIcon) {
		logicTopMenu.setDeleteActive(showDeleteIcon);
	}
	
	public final boolean hitTestIconDelete(float f, float f2) {
		return logicTopMenu.isInsideDeleteArea(f, f2);
	}
	
	public void c(Rs rs) {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_block_favorites_save_title);
		View a2 = wB.a(this, R.layout.property_popup_save_to_favorite);
		((TextView) a2.findViewById(R.id.tv_favorites_guide)).setText(R.string.logic_block_favorites_save_guide);
		EditText editText = a2.findViewById(R.id.ed_input);
		editText.setPrivateImeOptions("defaultInputmode=english;");
		editText.setLines(1);
		editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
		editText.setImeOptions(EditorInfo.IME_ACTION_DONE);
		NB nb = new NB(this, a2.findViewById(R.id.ti_input), Mp.h().g());
		dialog.setView(a2);
		dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
			if (nb.b()) {
				a(Helper.getText(editText), rs);
				v.dismiss();
			}
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void c(Ss ss) {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_editor_title_enter_string_value);
		View a2 = wB.a(this, R.layout.property_popup_input_text);
		((TextInputLayout) a2.findViewById(R.id.ti_input)).setHint(getString(R.string.property_hint_enter_value));
		EditText editText = a2.findViewById(R.id.ed_input);
		editText.setSingleLine(true);
		editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS);
		editText.setImeOptions(EditorInfo.IME_ACTION_DONE);
		editText.setText(ss.getArgValue().toString());
		dialog.setView(a2);
		dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
			a(ss, Helper.getText(editText));
			v.dismiss();
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void c(String str, String str2) {
		jC.a(scId).a(M.getJavaName(), str, str2);
		a(8, 0xff8a55d7);
	}
	
	public void c(boolean z) {
		logicTopMenu.setDetailActive(z);
	}
	
	public final boolean c(float f, float f2) {
		return logicTopMenu.isInsideDetailArea(f, f2);
	}
	
	private LinearLayout getFontPreview(String fontName) {
		LinearLayout linearLayout = new LinearLayout(this);
		linearLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (wB.a(this, 1.0f) * 60.0f)));
		linearLayout.setGravity(Gravity.CENTER | Gravity.LEFT);
		linearLayout.setOrientation(LinearLayout.HORIZONTAL);
		TextView name = new TextView(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT);
		layoutParams.weight = 1.0f;
		name.setLayoutParams(layoutParams);
		name.setText(fontName);
		linearLayout.addView(name);
		TextView preview = new TextView(this);
		preview.setLayoutParams(layoutParams);
		preview.setText("Preview");
		
		Typeface typeface;
		if (fontName.equalsIgnoreCase("default_font")) {
			typeface = Typeface.DEFAULT;
		} else {
			try {
				typeface = Typeface.createFromFile(jC.d(scId).d(fontName));
			} catch (RuntimeException e) {
				crashlytics.log("Loading font preview");
				crashlytics.recordException(e);
				typeface = Typeface.DEFAULT;
				preview.setText("Couldn't load font");
			}
		}
		
		preview.setTypeface(typeface);
		linearLayout.addView(preview);
		return linearLayout;
	}
	
	public RadioButton d(String type, String id) {
		if (isViewBindingEnabled) {
			id = ViewBindingBuilder.generateParameterFromId(id);
		}
		RadioButton radioButton = new RadioButton(this);
		radioButton.setText(type + " : " + id);
		radioButton.setTag(id);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (wB.a(this, 1.0f) * 40.0f));
		radioButton.setGravity(Gravity.CENTER | Gravity.LEFT);
		radioButton.setLayoutParams(layoutParams);
		return radioButton;
	}
	
	public void d(Ss ss) {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_editor_title_select_font);
		
		View customView = wB.a(this, R.layout.property_popup_selector_color);
		RadioGroup radioGroup = customView.findViewById(R.id.rg);
		LinearLayout linearLayout = customView.findViewById(R.id.content);
		ArrayList<String> fontNames = jC.d(scId).k();
		fontNames.add(0, "default_font");
		for (String fontName : fontNames) {
			RadioButton font = getFontRadioButton(fontName);
			radioGroup.addView(font);
			if (fontName.equals(ss.getArgValue())) {
				font.setChecked(true);
			}
			LinearLayout fontPreview = getFontPreview(fontName);
			fontPreview.setOnClickListener(v -> font.setChecked(true));
			linearLayout.addView(fontPreview);
		}
		
		dialog.setView(customView);
		dialog.setPositiveButton(R.string.common_word_select, (v, which) -> {
			for (int i = 0; i < radioGroup.getChildCount(); i++) {
				RadioButton radioButton = (RadioButton) radioGroup.getChildAt(i);
				if (radioButton.isChecked()) {
					a(ss, radioButton.getTag());
					break;
				}
			}
			v.dismiss();
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void d(boolean z) {
		logicTopMenu.setFavoriteActive(z);
	}
	
	public final boolean d(float f, float f2) {
		return logicTopMenu.isInsideFavoriteArea(f, f2);
	}
	
	public final RadioButton e(String str) {
		RadioButton radioButton = new RadioButton(this);
		radioButton.setText(str);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		layoutParams.topMargin = (int) wB.a(getContext(), 4.0f);
		layoutParams.bottomMargin = (int) wB.a(getContext(), 4.0f);
		radioButton.setGravity(Gravity.CENTER | Gravity.LEFT);
		radioButton.setLayoutParams(layoutParams);
		return radioButton;
	}
	
	public final CheckBox createCheckBox(String str) {
		CheckBox checkBox = new CheckBox(this);
		checkBox.setText(str);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		layoutParams.topMargin = (int) wB.a(getContext(), 4.0f);
		layoutParams.bottomMargin = (int) wB.a(getContext(), 4.0f);
		checkBox.setGravity(Gravity.CENTER | Gravity.LEFT);
		checkBox.setLayoutParams(layoutParams);
		return checkBox;
	}
	
	public void e(Ss ss) {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_editor_title_enter_data_value);
		View a2 = wB.a(this, R.layout.property_popup_input_intent_data);
		((TextView) a2.findViewById(R.id.tv_desc_intent_usage)).setText(getString(R.string.property_description_component_intent_usage));
		EditText editText = a2.findViewById(R.id.ed_input);
		((TextInputLayout) a2.findViewById(R.id.ti_input)).setHint(getString(R.string.property_hint_enter_value));
		editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
		editText.setText(ss.getArgValue().toString());
		dialog.setView(a2);
		dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
			a(ss, Helper.getText(editText));
			v.dismiss();
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void e(boolean z) {
		ObjectAnimator objectAnimator;
		if (!W) {
			h(getResources().getConfiguration().orientation);
		}
		if (X == z) {
			return;
		}
		X = z;
		n();
		if (z) {
			g(false);
			objectAnimator = U;
		} else {
			objectAnimator = V;
		}
		objectAnimator.start();
		f(getResources().getConfiguration().orientation);
	}
	
	public void f(int i) {
		LinearLayout.LayoutParams layoutParams;
		int a2;
		int i2 = ViewGroup.LayoutParams.MATCH_PARENT;
		if (X) {
			int width = getResources().getDisplayMetrics().widthPixels;
			int height = getResources().getDisplayMetrics().heightPixels;
			if (width <= height) {
				width = height;
			}
			if (2 == i) {
				i2 = width - ((int) wB.a(this, 320.0f));
				a2 = ViewGroup.LayoutParams.MATCH_PARENT;
			} else {
				a2 = viewLogicEditor.getHeight() - K.getHeight();
			}
			layoutParams = new LinearLayout.LayoutParams(i2, a2);
		} else {
			layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
		}
		viewLogicEditor.setLayoutParams(layoutParams);
		viewLogicEditor.requestLayout();
	}
	
	public void f(Ss ss) {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		View customView = wB.a(this, R.layout.property_popup_selector_single);
		ViewGroup viewGroup = customView.findViewById(R.id.rg_content);
		String xmlName = M.getXmlName();
		
		if (eventName.equals("onBindCustomView")) {
			var eC = jC.a(scId);
			var view = eC.c(xmlName, id);
			if (view == null) {
				view = eC.c("_drawer_" + xmlName, id);
			}
			if (view != null && view.customView != null) {
				xmlName = ProjectFileBean.getXmlName(view.customView);
			}
		}
		
		dialog.setTitle(R.string.logic_editor_title_select_view);
		ArrayList<ViewBean> views = jC.a(scId).d(xmlName);
		for (ViewBean viewBean : views) {
			String convert = viewBean.convert;
			String typeName = convert.isEmpty() ? ViewBean.getViewTypeName(viewBean.type) : IdGenerator.getLastPath(convert);
			if (!convert.equals("include")) {
				Set<String> toNotAdd = new Ox(new jq(), M).readAttributesToReplace(viewBean);
				if (!toNotAdd.contains("android:id")) {
					String classInfo = ss.getClassInfo().getClassName();
					if ((classInfo.equals("CheckBox") && viewBean.getClassInfo().a("CompoundButton")) || viewBean.getClassInfo().a(classInfo)) {
						viewGroup.addView(d(typeName, viewBean.id));
					}
				}
				ExtraMenuBean.setupSearchView(customView, viewGroup);
			}
		}
		
		for (int i = 0; i < viewGroup.getChildCount(); i++) {
			RadioButton radioButton = (RadioButton) viewGroup.getChildAt(i);
			String argValue = ss.getArgValue().toString();
			if (argValue.equals(radioButton.getTag().toString())) {
				radioButton.setChecked(true);
				break;
			}
		}
		
		dialog.setView(customView);
		dialog.setNeutralButton("Code Editor", (v, which) -> {
			AsdDialog editor = new AsdDialog(this);
			editor.setContent(ss.getArgValue().toString());
			editor.show();
			editor.setOnSaveClickListener(this, false, ss, editor);
			editor.setOnCancelClickListener(editor);
			v.dismiss();
		});
		dialog.setPositiveButton(R.string.common_word_select, (v, which) -> {
			for (int i = 0; i < viewGroup.getChildCount(); i++) {
				RadioButton radioButton = (RadioButton) viewGroup.getChildAt(i);
				if (radioButton.isChecked()) {
					a(ss, radioButton.getTag());
					break;
				}
			}
			v.dismiss();
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void f(boolean z) {
		logicTopMenu.toggleLayoutVisibility(z);
	}
	
	@Override
	public void finish() {
		bC.d(scId).b(s());
		super.finish();
	}
	
	private Context getContext() {
		return this;
	}
	
	public void g(int i) {
		RelativeLayout.LayoutParams layoutParams;
		int orientation;
		if (2 == i) {
			K.setLayoutParams(new LinearLayout.LayoutParams((int) wB.a(this, 320.0f), ViewGroup.LayoutParams.MATCH_PARENT));
			LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			params.gravity = Gravity.CENTER | Gravity.BOTTOM;
			int dimension = (int) getResources().getDimension(R.dimen.action_button_margin);
			params.setMargins(dimension, dimension, dimension, dimension);
			openBlocksMenuButton.setLayoutParams(params);
			layoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
			layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
			layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
			layoutParams.topMargin = GB.a(getContext());
			orientation = LinearLayout.HORIZONTAL;
		} else {
			K.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) wB.a(this, 240.0f)));
			LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			params.gravity = Gravity.CENTER | Gravity.RIGHT;
			int dimension2 = (int) getResources().getDimension(R.dimen.action_button_margin);
			params.setMargins(dimension2, dimension2, dimension2, dimension2);
			openBlocksMenuButton.setLayoutParams(params);
			layoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
			layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
			orientation = LinearLayout.VERTICAL;
		}
		J.setOrientation(orientation);
		J.setLayoutParams(layoutParams);
		h(i);
		f(i);
	}
	
	public void g(boolean z) {
		if (!ha) {
			t();
		}
		if (ia != z) {
			ia = z;
			l();
			(z ? fa : ga).start();
		}
	}
	
	public void h(int i) {
		boolean var2 = X;
		if (i == 2) {
			if (!var2) {
				J.setTranslationX(wB.a(this, 320.0F));
			} else {
				J.setTranslationX(0.0F);
			}
			J.setTranslationY(0.0F);
		} else {
			if (!var2) {
				J.setTranslationX(0.0F);
				J.setTranslationY(wB.a(this, 240.0F));
			} else {
				J.setTranslationX(0.0F);
				J.setTranslationY(0.0F);
			}
		}
		
		if (i == 2) {
			U = ObjectAnimator.ofFloat(J, View.TRANSLATION_X, 0.0F);
			V = ObjectAnimator.ofFloat(J, View.TRANSLATION_X, wB.a(this, 320.0F));
		} else {
			U = ObjectAnimator.ofFloat(J, View.TRANSLATION_Y, 0.0F);
			V = ObjectAnimator.ofFloat(J, View.TRANSLATION_Y, wB.a(this, 240.0F));
		}
		
		U.setDuration(500L);
		U.setInterpolator(new DecelerateInterpolator());
		V.setDuration(300L);
		V.setInterpolator(new DecelerateInterpolator());
		W = true;
	}
	
	public void h(Ss ss) {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_editor_title_select_sound);
		
		View customView = wB.a(this, R.layout.property_popup_selector_single);
		RadioGroup radioGroup = customView.findViewById(R.id.rg_content);
		
		SoundPool soundPool = new SoundPool.Builder()
		.setMaxStreams(1)
		.setAudioAttributes(new AudioAttributes.Builder()
		.setUsage(AudioAttributes.USAGE_MEDIA)
		.setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
		.build())
		.build();
		
		soundPool.setOnLoadCompleteListener((soundPool1, sampleId, status) -> {
			if (soundPool1 != null) {
				soundPool1.play(sampleId, 1, 1, 1, 0, 1);
			}
		});
		
		for (String soundName : jC.d(scId).p()) {
			RadioButton sound = e(soundName);
			radioGroup.addView(sound);
			if (soundName.equals(ss.getArgValue())) {
				sound.setChecked(true);
			}
			sound.setOnClickListener(v -> soundPool.load(jC.d(scId).i(Helper.getText(sound)), 1));
		}
		
		dialog.setView(customView);
		dialog.setPositiveButton(R.string.common_word_select, (v, which) -> {
			RadioButton checkedRadioButton = radioGroup.findViewById(radioGroup.getCheckedRadioButtonId());
			a(ss, Helper.getText(checkedRadioButton));
			v.dismiss();
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		
		// تحرير الذاكرة عند إغلاق النافذة
		dialog.setOnDismissListener(dialogInterface -> soundPool.release());
		
		dialog.show();
	}
	
	
	public void h(boolean z) {
		logicTopMenu.setDeleteActive(false);
		logicTopMenu.setCopyActive(false);
		logicTopMenu.setFavoriteActive(false);
		logicTopMenu.setDetailActive(false);
		if (!da) {
			x();
		}
		if (ea == z) {
			return;
		}
		ea = z;
		m();
		(z ? ba : ca).start();
	}
	
	public void i(Ss ss) {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_editor_title_select_typeface);
		View a3 = wB.a(this, R.layout.property_popup_selector_single);
		RadioGroup radioGroup = a3.findViewById(R.id.rg_content);
		for (Pair<Integer, String> pair : sq.a("property_text_style")) {
			RadioButton e = e(pair.second);
			radioGroup.addView(e);
			if (pair.second.equals(ss.getArgValue())) {
				e.setChecked(true);
			}
		}
		dialog.setView(a3);
		dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
			int childCount = radioGroup.getChildCount();
			for (int i = 0; i < childCount; i++) {
				RadioButton radioButton = (RadioButton) radioGroup.getChildAt(i);
				if (radioButton.isChecked()) {
					a(ss, Helper.getText(radioButton));
					break;
				}
			}
			
			v.dismiss();
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void l() {
		if (fa.isRunning()) {
			fa.cancel();
		}
		if (ga.isRunning()) {
			ga.cancel();
		}
	}
	
	public void l(String str) {
		jC.a(scId).o(M.getJavaName(), str);
		a(1, 0xffcc5b22);
	}
	
	public void m() {
		if (ba.isRunning()) {
			ba.cancel();
		}
		if (ca.isRunning()) {
			ca.cancel();
		}
	}
	
	public void m(String str) {
		jC.a(scId).p(M.getJavaName(), str);
		a(0, 0xffee7d16);
	}
	
	public void n() {
		if (U.isRunning()) {
			U.cancel();
		}
		if (V.isRunning()) {
			V.cancel();
		}
	}
	
	public void n(String str) {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
		dialog.setTitle(R.string.logic_block_favorites_delete_title);
		dialog.setMessage(R.string.logic_block_favorites_delete_message);
		dialog.setPositiveButton(R.string.common_word_delete, (v, which) -> {
			Mp.h().a(str, true);
			O.a(str);
			v.dismiss();
		});
		dialog.setNegativeButton(R.string.common_word_cancel, null);
		dialog.show();
	}
	
	public void o(String str) {
		Intent intent = new Intent(getContext(), ShowBlockCollectionActivity.class);
		intent.putExtra("block_name", str);
		startActivity(intent);
	}
	
	public boolean o() {
		return true;
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == 222) {
				c(data.getStringExtra("block_name"), data.getStringExtra("block_spec"));
			} else if (requestCode == 224) {
				a(7, 0xff2ca5e2);
			}
		}
	}
	
	@Override
	public void onBackPressed() {
		if (ia) {
			g(false);
			return;
		}
		if (X) {
			e(false);
			return;
		}
		k();
		if (!p()) {
			return;
		}
		L();
	}
	
	@Override
	public void onClick(View v) {
		if (!mB.a()) {
			Object tag = v.getTag();
			if (tag != null) {
				if (tag.equals("variableAdd")) {
					showAddNewVariableDialog();
				} else if (tag.equals("variableRemove")) {
					K();
				} else if (tag.equals("openResourcesEditor")) {
					openResourcesEditor();
				} else if (tag.equals("listAdd")) {
					G();
				} else if (tag.equals("listRemove")) {
					J();
				} else if (tag.equals("blockAdd")) {
					Intent intent = new Intent(this, MakeBlockActivity.class);
					intent.putExtra("sc_id", scId);
					intent.putExtra("project_file", M);
					intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivityForResult(intent, 222);
				} else if (tag.equals("componentAdd")) {
					AddComponentBottomSheet addComponentBottomSheet = AddComponentBottomSheet.newInstance(scId, M, () -> a(7, 0xff2ca5e2));
					addComponentBottomSheet.show(getSupportFragmentManager(), null);
				} else if (tag.equals("blockImport")) {
					I();
				}
			}
			int id = v.getId();
			if (id == R.id.btn_delete) {
				setResult(Activity.RESULT_OK, new Intent());
				finish();
			} else if (id == R.id.btn_cancel) {
				setResult(Activity.RESULT_CANCELED);
				finish();
			}
		}
	}
	
	@Override
	public void onConfigurationChanged(@NonNull Configuration configuration) {
		super.onConfigurationChanged(configuration);
		g(configuration.orientation);
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.logic_editor);
		if (!super.isStoragePermissionGranted()) {
			finish();
		}
		Parcelable parcelable;
		if (savedInstanceState == null) {
			scId = getIntent().getStringExtra("sc_id");
			id = getIntent().getStringExtra("id");
			eventName = getIntent().getStringExtra("event");
			parcelable = getIntent().getParcelableExtra("project_file");
		} else {
			scId = savedInstanceState.getString("sc_id");
			id = savedInstanceState.getString("id");
			eventName = savedInstanceState.getString("event");
			parcelable = savedInstanceState.getParcelable("project_file");
		}
		isViewBindingEnabled = new ProjectSettings(scId).getValue(ProjectSettings.SETTING_ENABLE_VIEWBINDING, "false").equals("true");
		M = (ProjectFileBean) parcelable;
		T = (int) wB.a(getContext(), (float) T);
		Toolbar toolbar = findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		toolbar.setNavigationOnClickListener(v -> {
			if (!mB.a()) {
				onBackPressed();
			}
		});
		G = new DB(getContext(), "P12").a("P12I0", true);
		minDist = ViewConfiguration.get(getContext()).getScaledTouchSlop();
		vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		String eventText = getIntent().getStringExtra("event_text");
		toolbar.setTitle(id.equals("_fab") ? "fab" : ReturnMoreblockManager.getMbName(id));
		toolbar.setSubtitle(eventText);
		paletteSelector = findViewById(R.id.palette_selector);
		paletteSelector.setOnBlockCategorySelectListener(this);
		m = findViewById(R.id.palette_block);
		dummy = findViewById(R.id.dummy);
		viewLogicEditor = findViewById(R.id.editor);
		o = viewLogicEditor.getBlockPane();
		J = findViewById(R.id.layout_palette);
		K = findViewById(R.id.area_palette);
		openBlocksMenuButton = findViewById(R.id.fab_toggle_palette);
		openBlocksMenuButton.setOnClickListener(v -> e(!X));
		logicTopMenu = findViewById(R.id.top_menu);
		O = findViewById(R.id.right_drawer);
		findViewById(R.id.search_header).setOnClickListener(v -> paletteSelector.showSearchDialog());
		extraPaletteBlock = new ExtraPaletteBlock(this, isViewBindingEnabled);
		svgUtils = new SvgUtils(this);
		svgUtils.initImageLoader();
		
		// Initialize syntax check UI
		syntaxCheckContainer = findViewById(R.id.syntax_check_container);
		syntaxCheckIcon = findViewById(R.id.syntax_check_icon);
		syntaxCheckText = findViewById(R.id.syntax_check_text);
		syntaxCheckContainer.setOnClickListener(v -> {
			LogicSyntaxChecker.SyntaxResult result = (LogicSyntaxChecker.SyntaxResult) v.getTag();
			if (result != null && !result.isValid) {
				new MaterialAlertDialogBuilder(this)
				.setTitle("Syntax Error Details")
				.setMessage(result.errorMessage)
				.setPositiveButton(R.string.common_word_ok, null)
				.show();
			}
		});
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.logic_menu, menu);
		menu.findItem(R.id.menu_logic_redo).setEnabled(M != null && bC.d(scId).g(s()));
		menu.findItem(R.id.menu_logic_undo).setEnabled(M != null && bC.d(scId).h(s()));
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(@NonNull MenuItem menuItem) {
		int itemId = menuItem.getItemId();
		
		if (itemId == R.id.menu_block_helper) {
			e(false);
			g(!ia);
		} else if (itemId == R.id.menu_logic_redo) {
			redo();
		} else if (itemId == R.id.menu_logic_undo) {
			undo();
		} else if (itemId == R.id.menu_logic_showsource) {
			new MaterialAlertDialogBuilder(this)
			.setTitle("Source Code")
			.setItems(new CharSequence[]{
				"View Source Code",
				"Code to Blocks",
				"Generate with AI"
			}, (dialog, which) -> {
				if (which == 0)      showSourceCode();
				else if (which == 1) showCodeToBlocksDialog();
				else                  showAiCodePromptDialog();
			})
			.setNegativeButton("Cancel", null)
			.show();
		}
		
		return super.onOptionsItemSelected(menuItem);
	}
	
	@Override
	public void onPostCreate(Bundle bundle) {
		super.onPostCreate(bundle);
		
		String title;
		if (eventName.equals("moreBlock")) {
			title = getString(R.string.root_spec_common_define) + " " + ReturnMoreblockManager.getLogicEditorTitle(jC.a(scId).b(M.getJavaName(), id));
		} else if (id.equals("_fab")) {
			title = xB.b().a(getContext(), "fab", eventName);
		} else {
			title = xB.b().a(getContext(), id, eventName);
		}
		String e1 = title;
		
		o.a(e1, eventName);
		
		ArrayList<String> spec = FB.c(e1);
		int blockId = 0;
		for (int i = 0; i < spec.size(); i++) {
			String specBit = spec.get(i);
			if (specBit.charAt(0) == '%') {
				Rs block = BlockUtil.getVariableBlock(getContext(), blockId + 1, specBit, "getArg");
				if (block != null) {
					block.setBlockType(1);
					o.addView(block);
					o.getRoot().a((Ts) o.getRoot().V.get(blockId), block);
					block.setOnTouchListener(this);
					blockId++;
				}
			}
		}
		
		o.getRoot().k();
		g(getResources().getConfiguration().orientation);
		a(0, 0xffee7d16);
		
		LoadEventBlocksTask loadEventBlocksTask = new LoadEventBlocksTask(this);
		loadEventBlocksTask.execute();
		
		z();
		triggerSyntaxCheck();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (!super.isStoragePermissionGranted()) {
			finish();
		}
	}
	
	// إضافة onDestroy لتنظيف الـ Activity بالكامل
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (syntaxExecutor != null && !syntaxExecutor.isShutdown()) {
			syntaxExecutor.shutdownNow();
		}
		if (activeAiRequest != null) {
			activeAiRequest.cancel();
		}
	}
	
	
	@Override
	public void onSaveInstanceState(Bundle bundle) {
		bundle.putString("sc_id", scId);
		bundle.putString("id", id);
		bundle.putString("event", eventName);
		bundle.putParcelable("project_file", M);
		super.onSaveInstanceState(bundle);
		ArrayList<BlockBean> blocks = o.getBlocks();
		eC a2 = jC.a(scId);
		String javaName = M.getJavaName();
		a2.a(javaName, id + "_" + eventName, blocks);
		jC.a(scId).k();
	}
	
	@Override
	public void onSelected(MoreBlockCollectionBean moreBlockCollectionBean) {
		new MoreblockImporter(this, scId, M).importMoreblock(moreBlockCollectionBean, () -> a(8, 0xff8a55d7));
	}
	
	@Override
	public boolean onTouch(View v, MotionEvent event) {
		int actionMasked = event.getActionMasked();
		if (event.getPointerId(event.getActionIndex()) > 0) {
			return true;
		}
		if (actionMasked == MotionEvent.ACTION_DOWN) {
			isDragged = false;
			handler.postDelayed(longPressed, ViewConfiguration.getLongPressTimeout() / 2);
			int[] locationOnScreen = new int[2];
			v.getLocationOnScreen(locationOnScreen);
			s = locationOnScreen[0];
			t = locationOnScreen[1];
			posInitX = event.getRawX();
			posInitY = event.getRawY();
			currentTouchedView = v;
			return true;
		}
		if (actionMasked == MotionEvent.ACTION_MOVE) {
			if (!isDragged) {
				if (Math.abs(posInitX - s - event.getX()) >= minDist || Math.abs(posInitY - t - event.getY()) >= minDist) {
					currentTouchedView = null;
					handler.removeCallbacks(longPressed);
				}
				return false;
			}
			handler.removeCallbacks(longPressed);
			float rawX = event.getRawX();
			float rawY = event.getRawY();
			dummy.a(v, rawX - s, rawY - t, posInitX - s, posInitY - t, S, T);
			if (hitTestIconDelete(event.getRawX(), event.getRawY())) {
				dummy.setAllow(true);
				activeIconDelete(true);
				a(false);
				d(false);
				c(false);
				return true;
			}
			activeIconDelete(false);
			if (a(event.getRawX(), event.getRawY())) {
				dummy.setAllow(true);
				a(true);
				d(false);
				c(false);
				return true;
			}
			a(false);
			if (d(event.getRawX(), event.getRawY())) {
				dummy.setAllow(true);
				d(true);
				c(false);
				return true;
			}
			d(false);
			if (c(event.getRawX(), event.getRawY())) {
				dummy.setAllow(true);
				c(true);
				return true;
			}
			c(false);
			dummy.a(this.v);
			if (viewLogicEditor.hitTest(this.v[0], this.v[1])) {
				dummy.setAllow(true);
				o.c((Rs) v, this.v[0], this.v[1]);
			} else {
				dummy.setAllow(false);
				o.d();
			}
			return true;
		} else if (actionMasked == MotionEvent.ACTION_UP) {
			currentTouchedView = null;
			handler.removeCallbacks(longPressed);
			if (!isDragged) {
				if (v instanceof Rs rs) {
					if (rs.getBlockType() == 0) {
						a(rs, event.getX(), event.getY());
					}
				}
				return false;
			}
			m.setDragEnabled(true);
			viewLogicEditor.setScrollEnabled(true);
			O.setDragEnabled(true);
			dummy.setDummyVisibility(View.GONE);
			if (!dummy.getAllow()) {
				Rs rs2 = (Rs) v;
				if (rs2.getBlockType() == 0) {
					o.a(rs2, 0);
					if (w != null) {
						if (x == 0) {
							w.ha = (Integer) v.getTag();
						}
						if (x == 2) {
							w.ia = (Integer) v.getTag();
						}
						if (x == 3) {
							w.ja = (Integer) v.getTag();
						}
						if (x == 5) {
							w.a((Ts) w.V.get(y), rs2);
						}
						rs2.E = w;
						w.p().k();
					} else {
						rs2.p().k();
					}
				}
				q();
			} else if (logicTopMenu.isDeleteActive) {
				Rs rs5 = (Rs) v;
				if (rs5.getBlockType() == 2) {
					g(true);
					n(rs5.T);
				} else {
					activeIconDelete(false);
					int id;
					try {
						id = Integer.parseInt(rs5.getBean().id);
					} catch (NumberFormatException e) {
						id = -1;
					}
					BlockBean blockBean2;
					if (w != null && id != -1) {
						BlockBean clone = w.getBean().clone();
						if (x == 0) {
							clone.nextBlock = id;
						} else if (x == 2) {
							clone.subStack1 = id;
						} else if (x == 3) {
							clone.subStack2 = id;
						} else if (x == 5) {
							clone.parameters.set(y, "@" + id);
						}
						blockBean2 = clone;
					} else {
						blockBean2 = null;
					}
					ArrayList<BlockBean> arrayList = new ArrayList<>();
					for (Rs allChild : rs5.getAllChildren()) {
						arrayList.add(allChild.getBean().clone());
					}
					b(rs5);
					BlockBean blockBean3 = null;
					if (w != null) {
						blockBean3 = w.getBean().clone();
					}
					int[] oLocationOnScreen = new int[2];
					o.getLocationOnScreen(oLocationOnScreen);
					bC.d(scId).b(s(), arrayList, ((int) s) - oLocationOnScreen[0], ((int) t) - oLocationOnScreen[1], blockBean2, blockBean3);
					C();
				}
			} else if (logicTopMenu.isFavoriteActive) {
				d(false);
				Rs rs7 = (Rs) v;
				o.a(rs7, 0);
				if (w != null) {
					if (x == 0) {
						w.ha = (Integer) v.getTag();
					}
					if (x == 2) {
						w.ia = (Integer) v.getTag();
					}
					if (x == 3) {
						w.ja = (Integer) v.getTag();
					}
					if (x == 5) {
						w.a((Ts) w.V.get(y), rs7);
					}
					rs7.E = w;
					w.p().k();
				} else {
					rs7.p().k();
				}
				c(rs7);
			} else if (logicTopMenu.isDetailActive) {
				c(false);
				if (v instanceof Us) {
					o(((Us) v).T);
				}
			} else if (logicTopMenu.isCopyActive) {
				a(false);
				Rs rs10 = (Rs) v;
				o.a(rs10, 0);
				if (w != null) {
					if (x == 0) {
						w.ha = (Integer) v.getTag();
					}
					if (x == 2) {
						w.ia = (Integer) v.getTag();
					}
					if (x == 3) {
						w.ja = (Integer) v.getTag();
					}
					if (x == 5) {
						w.a((Ts) w.V.get(y), rs10);
					}
					rs10.E = w;
					w.p().k();
				} else {
					// somehow the blocks is moving to the last position
					// commenting it to fix it too
					// rs10.p().k();
				}
				ArrayList<BlockBean> arrayList2 = new ArrayList<>();
				for (Rs rs : rs10.getAllChildren()) {
					BlockBean clone2 = rs.getBean().clone();
					int id;
					try {
						id = Integer.parseInt(clone2.id);
					} catch (NumberFormatException e) {
						id = -1;
					}
					if (id != -1) {
						clone2.id = String.valueOf(id + 99000000);
						if (clone2.nextBlock > 0) {
							clone2.nextBlock = clone2.nextBlock + 99000000;
						}
						if (clone2.subStack1 > 0) {
							clone2.subStack1 = clone2.subStack1 + 99000000;
						}
						if (clone2.subStack2 > 0) {
							clone2.subStack2 = clone2.subStack2 + 99000000;
						}
						for (int i = 0; i < clone2.parameters.size(); i++) {
							String parameter = clone2.parameters.get(i);
							if (parameter != null && !parameter.isEmpty() && parameter.charAt(0) == '@') {
								clone2.parameters.set(i, "@" + (Integer.parseInt(parameter.substring(1)) + 99000000));
							}
						}
						arrayList2.add(clone2);
					}
				}
				int[] nLocationOnScreen = new int[2];
				viewLogicEditor.getLocationOnScreen(nLocationOnScreen);
				int width = nLocationOnScreen[0] + (viewLogicEditor.getWidth() / 2);
				int a2 = nLocationOnScreen[1] + ((int) wB.a(getContext(), 4.0f));
				ArrayList<BlockBean> a3 = a(arrayList2, width, a2, true);
				int[] oLocationOnScreen = new int[2];
				o.getLocationOnScreen(oLocationOnScreen);
				bC.d(scId).a(s(), a3, width - oLocationOnScreen[0], a2 - oLocationOnScreen[1], null, null);
				C();
			} else if (v instanceof Rs rs13) {
				dummy.a(this.v);
				if (rs13.getBlockType() == 1) {
					int addTargetId = o.getAddTargetId();
					BlockBean clone3 = addTargetId >= 0 ? o.a(addTargetId).getBean().clone() : null;
					Rs a4 = a(rs13, this.v[0], this.v[1], false);
					BlockBean blockBean3 = null;
					if (addTargetId >= 0) {
						blockBean3 = o.a(addTargetId).getBean().clone();
					}
					int[] locationOnScreen = new int[2];
					o.getLocationOnScreen(locationOnScreen);
					bC.d(scId).a(s(), a4.getBean().clone(), this.v[0] - locationOnScreen[0], this.v[1] - locationOnScreen[1], clone3, blockBean3);
					if (clone3 != null) {
						clone3.print();
					}
					if (blockBean3 != null) {
						blockBean3.print();
					}
				} else if (rs13.getBlockType() == 2) {
					int addTargetId2 = o.getAddTargetId();
					BlockBean clone5 = addTargetId2 >= 0 ? o.a(addTargetId2).getBean().clone() : null;
					ArrayList<BlockBean> data = ((Us) v).getData();
					ArrayList<BlockBean> a5 = a(data, this.v[0], this.v[1], true);
					if (!a5.isEmpty()) {
						Rs a6 = o.a(a5.get(0).id);
						a(a6, this.v[0], this.v[1], true);
						BlockBean blockBean3 = null;
						if (addTargetId2 >= 0) {
							blockBean3 = o.a(addTargetId2).getBean().clone();
						}
						int[] locationOnScreen = new int[2];
						o.getLocationOnScreen(locationOnScreen);
						bC.d(scId).a(s(), a5, this.v[0] - locationOnScreen[0], this.v[1] - locationOnScreen[1], clone5, blockBean3);
					}
					o.c();
				} else {
					o.a(rs13, 0);
					int id = Integer.parseInt(rs13.getBean().id);
					BlockBean blockBean;
					if (w != null) {
						blockBean = w.getBean().clone();
						if (x == 0) {
							blockBean.nextBlock = id;
						} else if (x == 2) {
							blockBean.subStack1 = id;
						} else if (x == 3) {
							blockBean.subStack2 = id;
						} else if (x == 5) {
							blockBean.parameters.set(y, "@" + id);
						}
					} else {
						blockBean = null;
					}
					Rs a7 = o.a(o.getAddTargetId());
					BlockBean clone6 = a7 != null ? a7.getBean().clone() : null;
					ArrayList<Rs> allChildren3 = rs13.getAllChildren();
					ArrayList<BlockBean> arrayList3 = new ArrayList<>();
					for (Rs rs : allChildren3) {
						arrayList3.add(rs.getBean().clone());
					}
					a(rs13, this.v[0], this.v[1], true);
					ArrayList<BlockBean> arrayList4 = new ArrayList<>();
					for (Rs rs : allChildren3) {
						arrayList4.add(rs.getBean().clone());
					}
					BlockBean clone7 = w != null ? w.getBean().clone() : null;
					BlockBean blockBean3 = null;
					if (a7 != null) {
						blockBean3 = a7.getBean().clone();
					}
					if (blockBean == null || clone7 == null || !blockBean.isEqual(clone7)) {
						int[] locationOnScreen = new int[2];
						o.getLocationOnScreen(locationOnScreen);
						int x = locationOnScreen[0];
						int y = locationOnScreen[1];
						bC.d(scId).a(s(), arrayList3, arrayList4, ((int) s) - x, ((int) t) - y, this.v[0] - x, this.v[1] - y, blockBean, clone7, clone6, blockBean3);
					}
					o.c();
				}
				C();
				o.c();
			}
			dummy.setAllow(false);
			h(false);
			isDragged = false;
			return true;
		} else if (actionMasked == MotionEvent.ACTION_CANCEL) {
			handler.removeCallbacks(longPressed);
			isDragged = false;
			return false;
		} else if (actionMasked == MotionEvent.ACTION_SCROLL) {
			handler.removeCallbacks(longPressed);
			isDragged = false;
			return false;
		} else {
			return true;
		}
	}
	
	public boolean p() {
		return true;
	}
	
	public void q() {
	}
	
	private void r() {
		if (currentTouchedView != null) {
			m.setDragEnabled(false);
			viewLogicEditor.setScrollEnabled(false);
			O.setDragEnabled(false);
			if (ia) {
				g(false);
			}
			
			if (G) {
				vibrator.vibrate(100L);
			}
			
			isDragged = true;
			if (((Rs) currentTouchedView).getBlockType() == 0) {
				a((Rs) currentTouchedView);
				f(true);
				h(true);
				dummy.a((Rs) currentTouchedView);
				o.a((Rs) currentTouchedView, 8);
				o.c((Rs) currentTouchedView);
				o.a((Rs) currentTouchedView);
			} else if (((Rs) currentTouchedView).getBlockType() == 2) {
				f(false);
				h(true);
				dummy.a((Rs) currentTouchedView);
				o.a((Rs) currentTouchedView, ((Us) currentTouchedView).getData());
			} else {
				dummy.a((Rs) currentTouchedView);
				o.a((Rs) currentTouchedView);
			}
			
			float a = posInitX - s;
			float b = posInitY - t;
			dummy.a(currentTouchedView, a, b, a, b, S, T);
			dummy.a(v);
			if (viewLogicEditor.hitTest(v[0], v[1])) {
				dummy.setAllow(true);
				o.c((Rs) currentTouchedView, v[0], v[1]);
			} else {
				dummy.setAllow(false);
				o.d();
			}
		}
	}
	
	public final String s() {
		return bC.a(M.getJavaName(), id, eventName);
	}
	
	public void showSourceCode() {
		yq yq = new yq(this, scId);
		yq.a(jC.c(scId), jC.b(scId), jC.a(scId));
		String code = new Fx(M.getActivityName(), yq.N, o.getBlocks(), isViewBindingEnabled).a();
		var intent = new Intent(this, CodeViewerActivity.class);
		intent.putExtra("code", code);
		intent.putExtra("sc_id", scId);
		intent.putExtra("scheme", CodeViewerActivity.SCHEME_JAVA);
		startActivity(intent);
	}
	
	private void triggerSyntaxCheck() {
		syntaxCheckHandler.removeCallbacks(syntaxCheckRunnable);
		syntaxCheckHandler.postDelayed(syntaxCheckRunnable, 500);
	}
	
	
	private void runSyntaxCheck() {
		if (o == null || o.getBlocks().isEmpty()) {
			syntaxCheckContainer.setVisibility(View.GONE);
			return;
		}
		
		yq yq = new yq(this, scId);
		yq.a(jC.c(scId), jC.b(scId), jC.a(scId));
		
		syntaxExecutor.execute(() -> {
			LogicSyntaxChecker.SyntaxResult result = LogicSyntaxChecker.check(
			M.getActivityName(),
			yq.N,
			o.getBlocks(),
			isViewBindingEnabled
			);
			
			runOnUiThread(() -> {
				if (isFinishing() || isDestroyed()) return;
				syntaxCheckContainer.setVisibility(View.VISIBLE);
				syntaxCheckContainer.setTag(result);
				if (result.isValid) {
					syntaxCheckIcon.setImageResource(R.drawable.ic_check);
					syntaxCheckIcon.setColorFilter(ContextCompat.getColor(this, R.color.scolor_green_normal));
					syntaxCheckText.setText(R.string.logic_editor_syntax_ok);
					syntaxCheckText.setTextColor(ContextCompat.getColor(this, R.color.scolor_green_normal));
				} else {
					syntaxCheckIcon.setImageResource(R.drawable.ic_remove_grey600_24dp);
					syntaxCheckIcon.setColorFilter(ContextCompat.getColor(this, R.color.scolor_red_01));
					syntaxCheckText.setText(R.string.logic_editor_syntax_error_details);
					syntaxCheckText.setTextColor(ContextCompat.getColor(this, R.color.scolor_red_01));
				}
			});
		});
	}
	
	
	public void t() {
		fa = ObjectAnimator.ofFloat(O, View.TRANSLATION_X, 0.0f);
		fa.setDuration(500L);
		fa.setInterpolator(new DecelerateInterpolator());
		ga = ObjectAnimator.ofFloat(O, View.TRANSLATION_X, O.getHeight());
		ga.setDuration(300L);
		ga.setInterpolator(new DecelerateInterpolator());
		ha = true;
	}
	
	public void x() {
		ba = ObjectAnimator.ofFloat(logicTopMenu, View.TRANSLATION_Y, 0.0f);
		ba.setDuration(500L);
		ba.setInterpolator(new DecelerateInterpolator());
		ca = ObjectAnimator.ofFloat(logicTopMenu, View.TRANSLATION_Y, logicTopMenu.getHeight() * (-1));
		ca.setDuration(300L);
		ca.setInterpolator(new DecelerateInterpolator());
		da = true;
	}
	
	public void z() {
		O.a();
		for (BlockCollectionBean next : Mp.h().f()) {
			O.a(next.name, next.blocks).setOnTouchListener(this);
		}
	}
	
	private static class ProjectSaver extends MA {
		private final WeakReference<LogicEditorActivity> activity;
		
		public ProjectSaver(LogicEditorActivity logicEditorActivity) {
			super(logicEditorActivity);
			activity = new WeakReference<>(logicEditorActivity);
			logicEditorActivity.addTask(this);
		}
		
		@Override
		public void a() {
			activity.get().h();
			activity.get().finish();
		}
		
		@Override
		public void a(String str) {
			Toast.makeText(a, R.string.common_error_failed_to_save, Toast.LENGTH_SHORT).show();
			activity.get().h();
		}
		
		@Override
		public void b() {
			publishProgress("Now saving..");
			activity.get().E();
		}
	}
	
	public static class LoadEventBlocksTask {
		private final WeakReference<LogicEditorActivity> activityRef;
		
		public LoadEventBlocksTask(LogicEditorActivity activity) {
			activityRef = new WeakReference<>(activity);
		}
		
		public void execute() {
			LogicEditorActivity activity = getActivity();
			if (activity == null) return;
			
			activity.k();
			ExecutorService executor = Executors.newSingleThreadExecutor();
			executor.execute(() -> {
				try {
					LogicEditorActivity act = getActivity();
					if (act != null) {
						act.loadEventBlocks();
						act.runOnUiThread(() -> {
							if (act.isFinishing() || act.isDestroyed()) return;
							act.h();
						});
					}
				} finally {
					executor.shutdown(); // إغلاق الـ Thread فور الانتهاء
				}
			});
		}
		
		private LogicEditorActivity getActivity() {
			return activityRef.get();
		}
	}
	
	
	public class ImagePickerAdapter extends RecyclerView.Adapter<ImagePickerAdapter.ViewHolder> {
		
		private final ArrayList<String> images;
		private final OnImageSelectedListener listener;
		private final ArrayList<String> filteredImages;
		private final Map<String, View> imageCache = new HashMap<>();
		private String selectedImage;
		
		public ImagePickerAdapter(ArrayList<String> images, String selectedImage, OnImageSelectedListener listener) {
			this.images = images;
			this.selectedImage = selectedImage;
			this.listener = listener;
			filteredImages = new ArrayList<>(images);
		}
		
		@NonNull
		@Override
		public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
			ImagePickerItemBinding binding = ImagePickerItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
			return new ViewHolder(binding);
		}
		
		@Override
		public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
			String image = filteredImages.get(position);
			
			holder.binding.textView.setText(image);
			
			View imageView = imageCache.get(image);
			if (imageView == null) {
				imageView = setImageViewContent(image);
				imageCache.put(image, imageView);
			}
			
			if (imageView.getParent() != null) {
				((ViewGroup) imageView.getParent()).removeView(imageView);
			}
			
			holder.binding.layoutImg.removeAllViews();
			holder.binding.layoutImg.addView(imageView);
			
			holder.binding.radioButton.setChecked(image.equals(selectedImage));
			
			holder.binding.transparentOverlay.setOnClickListener(v -> {
				if (!image.equals(selectedImage)) {
					selectedImage = image;
					listener.onImageSelected(image);
					notifyDataSetChanged();
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return filteredImages.size();
		}
		
		public void filter(String query) {
			filteredImages.clear();
			if (query.isEmpty()) {
				filteredImages.addAll(images);
			} else {
				for (String image : images) {
					if (image.toLowerCase().contains(query)) {
						filteredImages.add(image);
					}
				}
			}
			notifyDataSetChanged();
		}
		
		public interface OnImageSelectedListener {
			void onImageSelected(String image);
		}
		
		public static class ViewHolder extends RecyclerView.ViewHolder {
			public final ImagePickerItemBinding binding;
			
			public ViewHolder(@NonNull ImagePickerItemBinding binding) {
				super(binding.getRoot());
				this.binding = binding;
			}
		}
	}
	
	private String buildViewContext() {
		StringBuilder sb = new StringBuilder();
		java.util.ArrayList<com.besome.sketch.beans.ViewBean> views = jC.a(scId).d(M.getXmlName());
		if (views == null) return "";
		for (com.besome.sketch.beans.ViewBean view : views) {
			if (view.id == null || view.id.isEmpty()) continue;
			sb.append(view.id)
			.append(": ")
			.append(com.besome.sketch.beans.ViewBean.getViewTypeName(view.type))
			.append("\n");
		}
		return sb.toString();
	}
	
	private String buildExistingEventCode() {
		try {
			yq yqExporter = new yq(this, scId);
			yqExporter.a(jC.c(scId), jC.b(scId), jC.a(scId));
			String code = new Fx(M.getActivityName(), yqExporter.N, o.getBlocks(), isViewBindingEnabled).a();
			return code == null ? "" : code.trim();
		} catch (Exception e) {
			return "";
		}
	}
	
	/**
* يعرض حوار إدخال حيث يكتب المستخدم وصف ما يريد توليده، ثم يبدأ التوليد.
*/	
	private void showAiCodePromptDialog() {
		int dp24 = (int) (24 * getResources().getDisplayMetrics().density);
		int dp16 = (int) (16 * getResources().getDisplayMetrics().density);
		int dp8 = (int) (8 * getResources().getDisplayMetrics().density);
		
		LinearLayout root = new LinearLayout(this);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setPadding(dp24, dp24, dp24, dp8);
		
		TextView title = new TextView(this);
		title.setText("Generate with AI");
		title.setTextSize(20);
		title.setTypeface(null, android.graphics.Typeface.BOLD);
		title.setTextColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurface));
		root.addView(title);
		
		TextView subtitle = new TextView(this);
		subtitle.setText("Describe what this \"" + eventName + "\" event should do. AI will write the logic and convert it to blocks.");
		subtitle.setTextSize(14);
		subtitle.setTextColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant));
		LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
		subParams.setMargins(0, dp8, 0, dp16);
		subtitle.setLayoutParams(subParams);
		root.addView(subtitle);
		
		com.google.android.material.card.MaterialCardView card = new com.google.android.material.card.MaterialCardView(this);
		card.setCardElevation(0);
		card.setRadius(dp8);
		card.setStrokeWidth((int) (1 * getResources().getDisplayMetrics().density));
		card.setStrokeColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOutlineVariant));
		card.setCardBackgroundColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorSurfaceVariant));
		
		EditText editText = new EditText(this);
		editText.setHint("e.g. show a toast saying Hello when this runs");
		editText.setBackground(null);
		editText.setPadding(dp16, dp16, dp16, dp16);
		editText.setInputType(android.text.InputType.TYPE_CLASS_TEXT
		| android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
		| android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
		editText.setMinLines(4);
		editText.setMaxLines(10);
		editText.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
		editText.setTextColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurface));
		editText.setHintTextColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOutline));
		
		card.addView(editText, new ViewGroup.LayoutParams(-1, -2));
		root.addView(card, new LinearLayout.LayoutParams(-1, -2));
		
		new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
		.setView(root)
		.setNegativeButton("Cancel", null)
		.setPositiveButton("Generate", (dialog, which) -> {
			String userIntent = editText.getText() == null ? "" : editText.getText().toString().trim();
			if (userIntent.isEmpty()) {
				pro.sketchware.utility.SketchwareUtil.toastError("Describe what this event should do first.");
				return;
			}
			generateCodeWithAi(userIntent);
		})
		.show();
	}
	
	/**
* يطلب من نموذج AI توليد كود Java حسب الوصف (userIntent).
* التنفيذ في خيط خلفي؛ عند النجاح يعرض حوار يسمح للمستخدم بنسخ/حفظ/إدراج الكود.
*/	
	
	public void generateCodeWithAi(String userIntent) {
		if (userIntent == null || userIntent.trim().isEmpty()) {
			Toast.makeText(this, "ادخل وصفًا لتوليد الكود.", Toast.LENGTH_SHORT).show();
			return;
		}
		
		String viewContext = buildViewContext();
		String existingCode = buildExistingEventCode();
		String activityName = M.getActivityName();
		
		// الآن استعمل LogicGenTask
		LogicGenTask task = new LogicGenTask(getApplicationContext(), userIntent, eventName, activityName, viewContext, existingCode);
		
		// بناء Material dialog مع ProgressBar (مثال: استخدم layout ai_progress_dialog.xml كما اقترحت سابقاً)
		MaterialAlertDialogBuilder dialogBuilder = new MaterialAlertDialogBuilder(this);
		dialogBuilder.setTitle("Generating code");
		View progressView = LayoutInflater.from(this).inflate(R.layout.ai_progress_dialog, null, false);
		dialogBuilder.setView(progressView);
		dialogBuilder.setCancelable(true);
		final androidx.appcompat.app.AlertDialog progressDialog = dialogBuilder.create();
		progressDialog.show();
		
		// ابدأ المهمة وخذ الـ handle
		activeAiRequest = task.start(new AiProviderService.StreamListener() {
			@Override
			public void onContent(String delta) { }
			
			@Override
			public void onReasoning(String delta) { }
			
			@Override
			public void onToolCall(String name, String arguments, String id) { }
			
			@Override
			public void onFinalMessage(String fullContent, String fullReasoning) {
				try { progressDialog.dismiss(); } catch (Exception ignored) {}
				String code = fullContent == null ? "" : fullContent;
				if (code.trim().isEmpty()) {
					Toast.makeText(LogicEditorActivity.this, "لم يُحصل على نتيجة من المزوّد.", Toast.LENGTH_SHORT).show();
					return;
				}
				runConversion(code, () -> BlocksConverter.convert(code));
			}
			
			@Override
			public void onDebug(String message) { /* optional */ }
			
			@Override
			public void onError(String message, Throwable t) {
				try { progressDialog.dismiss(); } catch (Exception ignored) {}
				if (t != null) {
					Toast.makeText(LogicEditorActivity.this, "فشل توليد الكود: " + t.getMessage(), Toast.LENGTH_LONG).show();
				} else {
					Toast.makeText(LogicEditorActivity.this, "Request error: " + message, Toast.LENGTH_LONG).show();
				}
			}
		});
		
		// ربط إلغاء الحوار بإلغاء الطلب
		progressDialog.setOnCancelListener(d -> {
			if (activeAiRequest != null) activeAiRequest.cancel();
		});
		progressDialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE); // optional if you added button
		
	}
	
	
	
	
	/**
* يعرض الشيفرة في CodeViewerActivity ثم يظهر حوار مع خيارات (Copy / Save to app / Close).
* استعمل هذا بدلاً من AlertDialog.setMessage لكود طويل.
*/	
	private void openCodeInViewerWithActions(String code) {
		// افتح viewer المدمج في المشروع لعرض الشيفرة مع تمييز/تمرير
		try {
			Intent intent = new Intent(this, CodeViewerActivity.class);
			intent.putExtra("code", code);
			intent.putExtra("sc_id", scId);
			intent.putExtra("scheme", CodeViewerActivity.SCHEME_JAVA);
			startActivity(intent);
		} catch (Exception e) {
			// إن لم يتوفر CodeViewerActivity لأي سبب، نواصل دون فشل
			if (crashlytics != null) crashlytics.recordException(e);
		}
		
		// عرض حوار إجراءاتٍ إضافية
		new AlertDialog.Builder(this)
		.setTitle("AI Result")
		.setMessage("The generated code is opened in the viewer. You can copy it or save it to the app storage.")
		.setPositiveButton("Copy", (dialog, which) -> {
			ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
			if (cm != null) {
				cm.setPrimaryClip(ClipData.newPlainText("generated_java", code));
				Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(this, "Clipboard not available", Toast.LENGTH_SHORT).show();
			}
		})
		.setNegativeButton("Save to app", (dialog, which) -> {
			boolean ok = saveGeneratedCodeToFile("generated_ai_code_" + System.currentTimeMillis() + ".java", code);
			Toast.makeText(this, ok ? "Saved to internal storage" : "Save failed", Toast.LENGTH_SHORT).show();
		})
		.setNeutralButton("Close", null)
		.show();
	}
	
	
	/** حفظ ابتدائي داخل مجلد ملفات التطبيق */
	private boolean saveGeneratedCodeToFile(String fileName, String code) {
		if (fileName == null || fileName.trim().isEmpty() || code == null) return false;
		try {
			java.io.File dir = new java.io.File(getFilesDir(), "ai_generated_code");
			if (!dir.exists()) dir.mkdirs();
			java.io.File out = new java.io.File(dir, fileName);
			try (java.io.FileOutputStream fos = new java.io.FileOutputStream(out)) {
				fos.write(code.getBytes(java.nio.charset.StandardCharsets.UTF_8));
				fos.flush();
			}
			return true;
		} catch (Exception e) {
			try { if (crashlytics != null) crashlytics.recordException(e); } catch (Exception ignored) {}
			return false;
		}
	}
	
	private void showCodeToBlocksDialog() {
		int dp24 = (int) (24 * getResources().getDisplayMetrics().density);
		int dp16 = (int) (16 * getResources().getDisplayMetrics().density);
		int dp8 = (int) (8 * getResources().getDisplayMetrics().density);
		
		LinearLayout root = new LinearLayout(this);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setPadding(dp24, dp24, dp24, dp8);
		
		TextView title = new TextView(this);
		title.setText("Code to Blocks");
		title.setTextSize(20);
		title.setTypeface(null, android.graphics.Typeface.BOLD);
		title.setTextColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurface));
		root.addView(title);
		
		TextView subtitle = new TextView(this);
		subtitle.setText("Paste your Java snippet below. Supported syntax (loops, variables, APIs) will become blocks. Unrecognized code is wrapped safely.");
		subtitle.setTextSize(14);
		subtitle.setTextColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant));
		LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
		subParams.setMargins(0, dp8, 0, dp16);
		subtitle.setLayoutParams(subParams);
		root.addView(subtitle);
		
		com.google.android.material.card.MaterialCardView card = new com.google.android.material.card.MaterialCardView(this);
		card.setCardElevation(0);
		card.setRadius(dp8);
		card.setStrokeWidth((int)(1 * getResources().getDisplayMetrics().density));
		card.setStrokeColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOutlineVariant));
		card.setCardBackgroundColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorSurfaceVariant));
		
		EditText editText = new EditText(this);
		editText.setHint("public void myLogic() {\n    // Code here\n}");
		editText.setBackground(null); // Transparent background
		editText.setPadding(dp16, dp16, dp16, dp16);
		editText.setInputType(android.text.InputType.TYPE_CLASS_TEXT 
		| android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE 
		| android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
		editText.setMinLines(8);
		editText.setMaxLines(18);
		editText.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
		editText.setVerticalScrollBarEnabled(true);
		editText.setTypeface(android.graphics.Typeface.MONOSPACE);
		editText.setTextColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurface));
		editText.setHintTextColor(pro.sketchware.utility.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOutline));
		
		card.addView(editText, new ViewGroup.LayoutParams(-1, -2));
		root.addView(card, new LinearLayout.LayoutParams(-1, -2));
		
		new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
		.setView(root)
		.setNegativeButton("Cancel", null)
		.setPositiveButton("Convert", (dialog, which) -> {
			String code = editText.getText() == null ? "" : editText.getText().toString().trim();
			
			if (code.isEmpty()) {
				pro.sketchware.utility.SketchwareUtil.toastError("Oops! You forgot to paste the code.");
				return;
			} else {
				runConversion(code, () -> BlocksConverter.convert(code));
			}
			
			
			
		})
		.show();
	}
	
	private void runConversion(String code, java.util.function.Supplier<BlocksConverter.ConversionResult> converterCall) {
		BlocksConverter.ConversionResult result;
		try {
			result = converterCall.get();
		} catch (Throwable t) {
			pro.sketchware.utility.SketchwareUtil.toastError("Converter failed: " + t.getMessage());
			return;
		}
		
		if (result == null || result.error != null) {
			pro.sketchware.utility.SketchwareUtil.toastError("Couldn't convert the code: " + (result == null ? "no result" : result.error));
			return;
		}
		
		int total    = result.blocks.size();
		int rec      = result.recognizedCount;
		int fallback = result.fallbackCount;
		
		String blockWord = total == 1 ? "block" : "blocks";
		String msg = "Here's what we found:\n\n"
		+ "✅  " + rec + " native " + (rec == 1 ? "block" : "blocks") + "\n"
		+ "⚠️  " + fallback + " \"Add Source Directly\" " + (fallback == 1 ? "block" : "blocks") + "\n\n"
		+ "Ready to add " + total + " " + blockWord + " to your project?";
		
		new MaterialAlertDialogBuilder(this)
		.setTitle("Ready to Insert?")
		.setMessage(msg)
		.setNegativeButton("Wait, go back", null)
		.setPositiveButton("Yes, insert them", (d2, w2) -> insertConvertedBlocks(result.blocks))
		.show();
	}
	
	private void insertConvertedBlocks(java.util.ArrayList<com.besome.sketch.beans.BlockBean> blocks) {
		if (blocks == null || blocks.isEmpty()) {
			pro.sketchware.utility.SketchwareUtil.toastError("No blocks to insert.");
			return;
		}
		int[] oLoc = new int[2];
		o.getLocationOnScreen(oLoc);
		int insertX = oLoc[0] + pro.sketchware.utility.SketchwareUtil.dpToPx(16);
		int insertY = oLoc[1] + pro.sketchware.utility.SketchwareUtil.dpToPx(80);
		
		java.util.ArrayList<com.besome.sketch.beans.BlockBean> inserted =
		a(blocks, insertX, insertY, true);
		
		bC.d(scId).a(s(), inserted,
		insertX - oLoc[0], insertY - oLoc[1], null, null);
		
		C();
		
		pro.sketchware.utility.SketchwareUtil.toast(
		inserted.size() + " block" + (inserted.size() != 1 ? "s" : "") + " inserted.");
	}
}
