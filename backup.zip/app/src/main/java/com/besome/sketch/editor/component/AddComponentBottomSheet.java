package com.besome.sketch.editor.component;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.besome.sketch.beans.ComponentBean;
import com.besome.sketch.beans.ProjectFileBean;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;

import mod.hey.studios.util.Helper;
import mod.hilal.saif.components.ComponentsHandler;
import pro.sketchware.R;
import pro.sketchware.databinding.ComponentAddItemBinding;
import pro.sketchware.databinding.LogicAddComponentBinding;
import pro.sketchware.dialogs.InnerAddComponentBottomSheet;
import pro.sketchware.utility.TranslationFunction;

public class AddComponentBottomSheet extends BottomSheetDialogFragment {
    private static final int MIN_COMPONENT_COLUMNS = 4;
    private static final int MAX_COMPONENT_COLUMNS = 6;
    private static final int COMPONENT_MIN_COLUMN_WIDTH_DP = 72;

    private String sc_id;
    private ProjectFileBean projectFileBean;

    private ArrayList<ComponentBean> componentList;
    private LogicAddComponentBinding binding;
    private OnComponentCreateListener onComponentCreateListener;

    public static AddComponentBottomSheet newInstance(String scId, ProjectFileBean projectFileBean, OnComponentCreateListener onComponentCreateListener) {
        AddComponentBottomSheet addComponentBottomSheet = new AddComponentBottomSheet();
        addComponentBottomSheet.setOnComponentCreateListener(onComponentCreateListener);
        Bundle args = new Bundle();
        args.putString("sc_id", scId);
        args.putParcelable("project_file_bean", projectFileBean);
        addComponentBottomSheet.setArguments(args);
        return addComponentBottomSheet;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle args = getArguments();
        sc_id = args.getString("sc_id");
        projectFileBean = args.getParcelable("project_file_bean");

        initializeComponentBeans();
    }

    private void initializeComponentBeans() {
        componentList = new ArrayList<>();
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_INTENT));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_SHAREDPREF));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_FILE_PICKER));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_CALENDAR));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_VIBRATOR));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_TIMERTASK));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_DIALOG));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_MEDIAPLAYER));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_SOUNDPOOL));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_OBJECTANIMATOR));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_CAMERA));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_GYROSCOPE));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_COMPASS));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_LIGHT_SENSOR));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_PROXIMITY_SENSOR));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_BAROMETER));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_STEP_COUNTER));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_WORK_MANAGER));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_ALARM_MANAGER));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_BIOMETRIC_MANAGER));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_FUSED_LOCATION_MANAGER));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_TEXT_TO_SPEECH));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_SPEECH_TO_TEXT));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_REQUEST_NETWORK));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_BLUETOOTH_CONNECT));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_LOCATION_MANAGER));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_PROGRESS_DIALOG));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_DATE_PICKER_DIALOG));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_TIME_PICKER_DIALOG));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_NOTIFICATION));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_FRAGMENT_ADAPTER));

        // Ads
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_INTERSTITIAL_AD));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_REWARDED_VIDEO_AD));

        // Firebase
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_FIREBASE));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_FIREBASE_AUTH));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_FIREBASE_STORAGE));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_FIREBASE_AUTH_PHONE));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_FIREBASE_CLOUD_MESSAGE));
        componentList.add(new ComponentBean(ComponentBean.COMPONENT_TYPE_FIREBASE_AUTH_GOOGLE_LOGIN));

        ComponentsHandler.add(componentList);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = LogicAddComponentBinding.inflate(getLayoutInflater());
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(requireContext(), MIN_COMPONENT_COLUMNS);
        RecyclerView componentListView = binding.componentList;

        binding.title.setText(Helper.getResString(R.string.component_title_add_component));
        componentListView.setHasFixedSize(true);
        componentListView.setAdapter(new ComponentsAdapter());
        componentListView.setLayoutManager(gridLayoutManager);
        componentListView.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) ->
                updateComponentGridSpan((RecyclerView) v, gridLayoutManager));
        componentListView.post(() -> updateComponentGridSpan(componentListView, gridLayoutManager));

        componentListView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                GridLayoutManager lm = (GridLayoutManager) recyclerView.getLayoutManager();
                if (lm == null) return;
                int first = lm.findFirstCompletelyVisibleItemPosition();
                int last = lm.findLastCompletelyVisibleItemPosition();
                RecyclerView.Adapter<?> adapter = recyclerView.getAdapter();
                int total = adapter == null ? 0 : adapter.getItemCount();
                binding.dividerTop.setVisibility(first > 0 ? View.VISIBLE : View.GONE);
                binding.dividerBottom.setVisibility(last < total - 1 ? View.VISIBLE : View.GONE);
            }
        });
    }

    private void updateComponentGridSpan(@NonNull RecyclerView componentListView, @NonNull GridLayoutManager gridLayoutManager) {
        int availableWidth = componentListView.getWidth()
                - componentListView.getPaddingLeft()
                - componentListView.getPaddingRight();
        if (availableWidth <= 0) {
            return;
        }

        int minColumnWidth = Math.round(COMPONENT_MIN_COLUMN_WIDTH_DP * getResources().getDisplayMetrics().density);
        int spanCount = availableWidth / minColumnWidth;
        spanCount = Math.max(MIN_COMPONENT_COLUMNS, Math.min(MAX_COMPONENT_COLUMNS, spanCount));
        if (gridLayoutManager.getSpanCount() != spanCount) {
            gridLayoutManager.setSpanCount(spanCount);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        onComponentCreateListener = null;
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putString("sc_id", sc_id);
        savedInstanceState.putParcelable("project_file", projectFileBean);
        super.onSaveInstanceState(savedInstanceState);
    }

    private void setOnComponentCreateListener(OnComponentCreateListener onComponentCreateListener) {
        this.onComponentCreateListener = onComponentCreateListener;
    }

    private void showAddComponentDialog(ComponentBean componentBean) {
        InnerAddComponentBottomSheet innerAddComponentBottomSheet = InnerAddComponentBottomSheet.newInstance(sc_id, projectFileBean, componentBean, sheet -> {
            sheet.dismiss();
            dismiss();
            if (onComponentCreateListener != null) {
                onComponentCreateListener.invoke();
            }
        });
        innerAddComponentBottomSheet.show(getParentFragmentManager(), null);
    }

    public interface OnComponentCreateListener {
        void invoke();
    }

    private class ComponentsAdapter extends RecyclerView.Adapter<ComponentsAdapter.ComponentBeanViewHolder> {
        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public void onBindViewHolder(@NonNull ComponentBeanViewHolder holder, int position) {
            var componentBean = componentList.get(position);
            holder.bind(componentBean);
        }

        @Override
        @NonNull
        public ComponentBeanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ComponentAddItemBinding binding = ComponentAddItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new ComponentBeanViewHolder(binding);
        }

        @Override
        public int getItemCount() {
            return componentList.size();
        }

        private class ComponentBeanViewHolder extends RecyclerView.ViewHolder {
            private final ComponentAddItemBinding binding;

            public ComponentBeanViewHolder(ComponentAddItemBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }

            public void bind(ComponentBean componentBean) {
                String componentName = ComponentBean.getComponentName(itemView.getContext(), componentBean.type);
                binding.name.setText(componentName);
                binding.icon.setImageResource(ComponentBean.getIconResource(componentBean.type));
                binding.getRoot().setOnClickListener(v -> showAddComponentDialog(componentBean));
            }
        }
    }
}
